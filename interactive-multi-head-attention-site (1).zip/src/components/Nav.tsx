import { useEffect, useState } from "react";
import { cn } from "../utils/cn";

const SECTIONS = [
  { id: "intro", label: "Основы" },
  { id: "playground", label: "Песочница" },
  { id: "steps", label: "Пошагово" },
  { id: "compare", label: "Сравнение" },
  { id: "masking", label: "Маски" },
  { id: "code", label: "Код" },
  { id: "quiz", label: "Квиз" },
];

export function Nav() {
  const [active, setActive] = useState("intro");
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const obs = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) setActive(e.target.id);
        });
      },
      { rootMargin: "-45% 0px -50% 0px" }
    );
    SECTIONS.forEach((s) => {
      const el = document.getElementById(s.id);
      if (el) obs.observe(el);
    });
    return () => obs.disconnect();
  }, []);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all",
        scrolled ? "border-b border-white/10 bg-slate-950/80 backdrop-blur-xl" : "bg-transparent"
      )}
    >
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6">
        <a href="#top" className="flex items-center gap-2.5">
          <span className="relative flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-sky-400 via-cyan-400 to-violet-500 shadow-lg shadow-sky-500/25">
            <svg viewBox="0 0 24 24" className="h-5 w-5 text-slate-950" fill="none" stroke="currentColor" strokeWidth={2.2}>
              <circle cx="6" cy="6" r="2" />
              <circle cx="6" cy="18" r="2" />
              <circle cx="18" cy="12" r="2" />
              <path d="M7.6 7.4 16.4 11M7.6 16.6 16.4 13" />
            </svg>
          </span>
          <span className="text-sm font-bold tracking-tight text-white sm:text-base">
            MHA<span className="text-sky-400">.</span>Lab
          </span>
        </a>

        <nav className="hidden items-center gap-1 lg:flex">
          {SECTIONS.map((s) => (
            <a
              key={s.id}
              href={`#${s.id}`}
              className={cn(
                "rounded-lg px-3 py-1.5 text-sm font-medium transition",
                active === s.id
                  ? "bg-white/10 text-white"
                  : "text-slate-400 hover:bg-white/5 hover:text-slate-200"
              )}
            >
              {s.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <a
            href="#playground"
            className="hidden rounded-lg bg-gradient-to-r from-sky-500 to-cyan-400 px-3.5 py-2 text-xs font-semibold text-slate-950 transition hover:brightness-110 sm:inline-flex"
          >
            Открыть песочницу
          </a>
          <button
            type="button"
            onClick={() => setOpen((o) => !o)}
            className="rounded-lg border border-white/10 p-2 text-slate-300 lg:hidden"
            aria-label="Меню"
          >
            <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth={2}>
              {open ? <path d="M6 6l12 12M18 6L6 18" /> : <path d="M4 7h16M4 12h16M4 17h16" />}
            </svg>
          </button>
        </div>
      </div>

      {open && (
        <div className="border-t border-white/10 bg-slate-950/95 px-4 py-3 lg:hidden">
          <div className="grid grid-cols-2 gap-2">
            {SECTIONS.map((s) => (
              <a
                key={s.id}
                href={`#${s.id}`}
                onClick={() => setOpen(false)}
                className="rounded-lg bg-white/5 px-3 py-2 text-sm text-slate-300"
              >
                {s.label}
              </a>
            ))}
          </div>
        </div>
      )}
    </header>
  );
}
