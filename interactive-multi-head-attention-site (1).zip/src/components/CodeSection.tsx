import { useState } from "react";
import { Card, SectionTitle } from "./ui";
import { cn } from "../utils/cn";

const KEYWORDS = new Set([
  "def", "class", "return", "import", "from", "as", "if", "else", "elif", "for", "in", "while",
  "with", "None", "True", "False", "and", "or", "not", "lambda", "pass", "break", "continue",
  "assert", "yield", "global",
]);

function highlight(code: string) {
  const parts = code.split(
    /("""[\s\S]*?"""|#[^\n]*|"(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*'|\b\d+(?:\.\d+)?\b|[A-Za-z_][A-Za-z_0-9]*)/g
  );
  return parts.map((p, i) => {
    if (!p) return null;
    if (i % 2 === 0) return <span key={i}>{p}</span>;
    if (p.startsWith("#")) return <span key={i} className="italic text-slate-500">{p}</span>;
    if (/^["']/.test(p)) return <span key={i} className="text-emerald-300">{p}</span>;
    if (/^\d/.test(p)) return <span key={i} className="text-amber-300">{p}</span>;
    if (KEYWORDS.has(p)) return <span key={i} className="text-violet-300">{p}</span>;
    if (/^[A-Z]/.test(p)) return <span key={i} className="text-sky-300">{p}</span>;
    if (p.endsWith("(") || p.includes("(")) return <span key={i} className="text-cyan-200">{p}</span>;
    return <span key={i} className="text-slate-300">{p}</span>;
  });
}

const PYTORCH_CODE = `# Готовый модуль PyTorch
import torch
import torch.nn as nn

class MultiHeadAttention(nn.Module):
    def __init__(self, d_model, n_heads, dropout=0.1):
        super().__init__()
        assert d_model % n_heads == 0
        self.d_model = d_model
        self.n_heads = n_heads
        self.d_k = d_model // n_heads

        # 4 матрицы: Q, K, V и выходная проекция W^O
        self.q_proj = nn.Linear(d_model, d_model)
        self.k_proj = nn.Linear(d_model, d_model)
        self.v_proj = nn.Linear(d_model, d_model)
        self.out_proj = nn.Linear(d_model, d_model)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x, mask=None):
        B, L, D = x.shape

        # 1) проекции: (B, L, D) -> (B, n_heads, L, d_k)
        q = self.q_proj(x).view(B, L, self.n_heads, self.d_k).transpose(1, 2)
        k = self.k_proj(x).view(B, L, self.n_heads, self.d_k).transpose(1, 2)
        v = self.v_proj(x).view(B, L, self.n_heads, self.d_k).transpose(1, 2)

        # 2) скалярные произведения + масштабирование
        scores = q @ k.transpose(-2, -1) / (self.d_k ** 0.5)

        # 3) маска: -inf в запрещённых позициях
        if mask is not None:
            scores = scores.masked_fill(mask == 0, float("-inf"))

        # 4) softmax по строке (ось -1 — это ключи)
        attn = torch.softmax(scores, dim=-1)
        attn = self.dropout(attn)

        # 5) взвешенная сумма значений
        out = attn @ v                       # (B, n_heads, L, d_k)

        # 6) конкатенация голов и общая проекция W^O
        out = out.transpose(1, 2).contiguous().view(B, L, D)
        return self.out_proj(out), attn
`;

const MANUAL_CODE = `# Своя реализация «в лоб» — всё видно своими глазами
import math
import torch

def scaled_dot_product_attention(q, k, v, mask=None):
    # q, k, v: (L, d_k)
    d_k = q.size(-1)

    scores = q @ k.transpose(-2, -1) / math.sqrt(d_k)   # масштабирование

    if mask is not None:
        scores = scores.masked_fill(mask, float("-inf"))

    weights = torch.softmax(scores, dim=-1)            # вероятности
    out = weights @ v                                  # взвешенная сумма
    return out, weights

def multi_head_attention(x, Wq, Wk, Wv, Wo, n_heads, mask=None):
    # x: (L, d_model)
    L, d_model = x.shape
    d_head = d_model // n_heads

    heads, all_weights = [], []

    for h in range(n_heads):
        sl = slice(h * d_head, (h + 1) * d_head)

        q = x @ Wq[:, sl]      # проекция только этого подпространства
        k = x @ Wk[:, sl]
        v = x @ Wv[:, sl]

        out, w = scaled_dot_product_attention(q, k, v, mask)
        heads.append(out)
        all_weights.append(w)

    # конкатенация по голов и общая проекция
    concat = torch.cat(heads, dim=-1)   # (L, d_model)
    return concat @ Wo, all_weights
`;

const NUMPY_CODE = `# Интерактивный прототип того, что вы видели в песочнице
import numpy as np

def softmax(x):
    e = np.exp(x - x.max(axis=-1, keepdims=True))
    return e / e.sum(axis=-1, keepdims=True)

def attention(x, Wq, Wk, Wv, Wo, n_heads, causal=False):
    L, d_model = x.shape
    d_head = d_model // n_heads

    out_all = []
    for h in range(n_heads):
        sl = slice(h * d_head, (h + 1) * d_head)
        q, k, v = x @ Wq[:, sl], x @ Wk[:, sl], x @ Wv[:, sl]

        scores = q @ k.T / np.sqrt(d_head)

        if causal:
            mask = np.triu(np.ones((L, L)), k=1).astype(bool)
            scores[mask] = -np.inf   # в NumPy нет masked_fill

        w = softmax(scores)
        out_all.append(w @ v)

    concat = np.concatenate(out_all, axis=-1)
    return concat @ Wo
`;

const TABS = [
  { id: "torch", label: "PyTorch (nn.Module)", code: PYTORCH_CODE },
  { id: "manual", label: "Вручную, по шагам", code: MANUAL_CODE },
  { id: "numpy", label: "NumPy-прототип", code: NUMPY_CODE },
];

export function CodeSection() {
  const [tab, setTab] = useState("torch");
  const active = TABS.find((t) => t.id === tab)!;

  return (
    <section id="code" className="relative mx-auto max-w-7xl px-4 py-20 sm:px-6 sm:py-24">
      <SectionTitle
        eyebrow="Код"
        title="Реализация на практике"
        subtitle="Те же формулы, что и в песочнице, — только на настоящем фреймворке. Сравните с пошаговым разбором: структура кода повторяет структуру вычислений."
        icon={
          <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth={2.2}>
            <path d="m8 6-6 6 6 6M16 6l6 6-6 6" />
          </svg>
        }
      />

      <div className="mb-4 flex flex-wrap gap-1.5">
        {TABS.map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setTab(t.id)}
            className={cn(
              "rounded-lg border px-3 py-1.5 text-xs font-semibold transition",
              tab === t.id
                ? "border-sky-400/50 bg-sky-400/15 text-white"
                : "border-white/10 bg-white/5 text-slate-400 hover:text-slate-200"
            )}
          >
            {t.label}
          </button>
        ))}
      </div>

      <Card className="overflow-hidden p-0">
        <div className="flex items-center gap-2 border-b border-white/10 bg-slate-900/60 px-4 py-2.5">
          <span className="h-3 w-3 rounded-full bg-rose-500/70" />
          <span className="h-3 w-3 rounded-full bg-amber-500/70" />
          <span className="h-3 w-3 rounded-full bg-emerald-500/70" />
          <span className="ml-2 font-mono text-[11px] text-slate-500">
            {active.id === "torch" ? "attention.py" : active.id === "manual" ? "manual_attention.py" : "numpy_attention.py"}
          </span>
        </div>
        <pre className="overflow-x-auto p-4 font-mono text-[11px] leading-relaxed sm:p-5 sm:text-xs">
          <code>{highlight(active.code)}</code>
        </pre>
      </Card>

      <div className="mt-4 grid gap-4 md:grid-cols-3">
        {[
          {
            t: "Параллельность",
            d: "Все головы считаются одной матричной операцией: reshape превращает (B, L, D) в (B, H, L, d_k) без цикла по Python.",
            c: "#38bdf8",
          },
          {
            t: "Ось softmax",
            d: "Softmax применяется по последней оси (ключи) — каждая строка становится распределением. Маска применяется ДО softmax.",
            c: "#fbbf24",
          },
          {
            t: "Память",
            d: "Матрица внимания имеет размер B×H×L×L. Для длинного контекста это основной расход памяти — отсюда FlashAttention и разреженное внимание.",
            c: "#a78bfa",
          },
        ].map((x) => (
          <Card key={x.t} className="p-5" glow={x.c}>
            <h4 className="text-sm font-semibold" style={{ color: x.c }}>
              {x.t}
            </h4>
            <p className="mt-2 text-sm leading-relaxed text-slate-400">{x.d}</p>
          </Card>
        ))}
      </div>
    </section>
  );
}
