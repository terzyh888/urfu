import { useState } from "react";
import type { Lab } from "../lib/lab";
import { TOKEN_PRESETS } from "../lib/lab";
import { fmt, headColor, mean, truncate, type Mat } from "../lib/attention";
import { Heatmap, HeatLegend } from "./Heatmap";
import { AttentionFlow } from "./AttentionFlow";
import { VectorBars } from "./VectorBars";
import { Badge, Card, GhostButton, SectionTitle, Segmented, Slider, Stat, Toggle } from "./ui";
import { cn } from "../utils/cn";

type Tab = "matrices" | "flow" | "vectors" | "output";

export function Playground({ lab }: { lab: Lab }) {
  const {
    tokens,
    setTokens,
    dModel,
    setDModel,
    nHeads,
    setNHeads,
    scaled,
    setScaled,
    causal,
    setCausal,
    seed,
    randomize,
    heads,
    updateHead,
    resetHeads,
    selectedHead,
    setSelectedHead,
    selectedToken,
    setSelectedToken,
    result,
    single,
    outputSimilarity,
  } = lab;

  const [tab, setTab] = useState<Tab>("matrices");
  const [text, setText] = useState<string>(TOKEN_PRESETS[0].tokens.join("\n"));

  const head = result.heads[Math.min(selectedHead, result.heads.length - 1)];
  const maxWeight = Math.max(...result.heads.flatMap((h) => h.weights.flat().filter(isFinite)), 1e-9);
  const avgEntropy = mean(result.heads.flatMap((h) => h.entropy));

  /* авто-анализ: на что чаще всего «смотрит» голова (без учёта себя) */
  const headInsight = (idx: number) => {
    const h = result.heads[idx];
    const n = h.weights.length;
    const sums = tokens.map((_, j) => {
      let s = 0;
      let c = 0;
      for (let i = 0; i < n; i++) {
        if (i === j) continue;
        s += h.weights[i][j];
        c++;
      }
      return c ? s / c : 0;
    });
    let best = 0;
    sums.forEach((v, j) => {
      if (v > sums[best]) best = j;
    });
    const focus = mean(h.weights.map((row) => Math.max(...row)));
    return { token: tokens[best] ?? "", avg: sums[best], focus };
  };

  const applyPreset = (tokensArr: string[]) => {
    setText(tokensArr.join("\n"));
    setTokens(tokensArr);
  };

  const handleText = (v: string) => {
    setText(v);
    const parsed = v.split(/\n+/).map((s) => s.trim()).filter(Boolean);
    if (parsed.length) setTokens(parsed);
  };

  const TABS: { id: Tab; label: string }[] = [
    { id: "matrices", label: "Матрицы внимания" },
    { id: "flow", label: "Потоки" },
    { id: "vectors", label: "Q / K / V" },
    { id: "output", label: "Выход модели" },
  ];

  return (
    <section id="playground" className="relative mx-auto max-w-7xl px-4 py-20 sm:px-6 sm:py-24">
      <SectionTitle
        eyebrow="Песочница"
        title="Экспериментируйте с головами внимания"
        subtitle="Все числа считаются по-настоящему: Q = XW_Q, K = XW_K, V = XW_V, softmax(QKᵀ/√d_k)V. Меняйте параметры — и смотрите, как меняется внимание и выход."
        icon={
          <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth={2.2}>
            <path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M5.6 18.4l2.1-2.1M16.3 7.7l2.1-2.1" />
            <circle cx="12" cy="12" r="3" />
          </svg>
        }
      />

      <div className="grid gap-6 lg:grid-cols-[330px_1fr]">
        {/* ------------------------------ Панель управления ----------------------------- */}
        <div className="space-y-4">
          <Card className="p-4">
            <h3 className="mb-3 text-xs font-semibold uppercase tracking-wider text-slate-400">
              Входная последовательность
            </h3>
            <textarea
              value={text}
              onChange={(e) => handleText(e.target.value)}
              spellCheck={false}
              className="h-36 w-full resize-y rounded-xl border border-white/10 bg-slate-900/70 p-3 font-mono text-xs leading-relaxed text-slate-200 outline-none transition focus:border-sky-400/60"
              placeholder="По одному токену в строке"
            />
            <div className="mt-2 flex flex-wrap gap-1.5">
              {TOKEN_PRESETS.map((p) => (
                <button
                  key={p.label}
                  type="button"
                  onClick={() => applyPreset(p.tokens)}
                  title={p.hint}
                  className="rounded-lg border border-white/10 bg-white/5 px-2 py-1 text-[11px] text-slate-300 transition hover:border-sky-400/40 hover:bg-sky-400/10 hover:text-white"
                >
                  {p.label}
                </button>
              ))}
            </div>
            <div className="mt-2 text-[11px] text-slate-500">
              Токенов: <span className="font-mono text-slate-300">{tokens.length}</span> (максимум 12)
            </div>
          </Card>

          <Card className="space-y-4 p-4">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
              Архитектура
            </h3>
            <Segmented
              label="Число голов"
              value={nHeads}
              onChange={setNHeads}
              options={[
                { value: 1, label: "1" },
                { value: 2, label: "2" },
                { value: 4, label: "4" },
                { value: 8, label: "8" },
              ]}
            />
            <Segmented
              label="Размерность модели d_model"
              value={dModel}
              onChange={setDModel}
              options={[
                { value: 16, label: "16" },
                { value: 32, label: "32" },
                { value: 64, label: "64" },
                { value: 128, label: "128" },
              ]}
            />
            <div>
              <div className="mb-2 text-xs font-medium uppercase tracking-wider text-slate-500">
                Зерно случайных весов
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  value={seed}
                  onChange={(e) => lab.setSeed(Number(e.target.value) || 0)}
                  className="w-20 rounded-lg border border-white/10 bg-slate-900/70 px-2 py-1.5 text-center font-mono text-xs text-slate-200 outline-none focus:border-sky-400/60"
                />
                <GhostButton onClick={randomize} className="flex-1">
                  🎲 Новые веса
                </GhostButton>
              </div>
            </div>
            <div className="rounded-xl border border-white/10 bg-slate-900/40 px-3 py-2 text-[11px] leading-relaxed text-slate-400">
              d_head = <span className="font-mono text-sky-300">{result.dHead}</span> — размерность одной
              головы ({dModel} / {nHeads}). Именно столько измерений приходит из каждой головы в
              конкатенацию.
            </div>
          </Card>

          <Card className="space-y-3 p-4">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
              Механика внимания
            </h3>
            <Toggle
              checked={scaled}
              onChange={setScaled}
              label="Масштабирование ÷ √d_k"
              hint="Стабилизирует softmax при больших d_k"
            />
            <Toggle
              checked={causal}
              onChange={setCausal}
              label="Причинная маска"
              hint="Токен видит только себя и прошлое"
            />
          </Card>

          <Card className="p-4">
            <div className="mb-3 flex items-center justify-between">
              <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                Настройки голов
              </h3>
              <GhostButton onClick={resetHeads}>Сброс</GhostButton>
            </div>
            <div className="max-h-[26rem] space-y-3 overflow-y-auto pr-1">
              {heads.map((h, i) => (
                <div
                  key={h.id}
                  className={cn(
                    "rounded-xl border p-3 transition",
                    i === selectedHead
                      ? "border-white/25 bg-white/[0.06]"
                      : "border-white/10 bg-slate-900/40"
                  )}
                >
                  <button
                    type="button"
                    onClick={() => setSelectedHead(i)}
                    className="mb-2 flex w-full items-center gap-2 text-left"
                  >
                    <span className="h-2.5 w-2.5 rounded-full" style={{ background: headColor(i) }} />
                    <span className="text-sm font-semibold text-white">Голова {i + 1}</span>
                    <span className="ml-auto font-mono text-[10px] text-slate-500">
                      d={result.dHead}
                    </span>
                  </button>

                  <label className="mb-2 block text-[11px] text-slate-400">
                    Усилить внимание к токену:
                    <select
                      value={Math.min(h.target, tokens.length - 1)}
                      onChange={(e) => updateHead(h.id, { target: Number(e.target.value) })}
                      className="mt-1 w-full rounded-lg border border-white/10 bg-slate-900/70 px-2 py-1.5 text-xs text-slate-200 outline-none focus:border-sky-400/60"
                    >
                      {tokens.map((t, ti) => (
                        <option key={ti} value={ti}>
                          {ti + 1}. {truncate(t, 18)}
                        </option>
                      ))}
                    </select>
                  </label>

                  <div className="space-y-2">
                    <Slider
                      label="Смещение (bias)"
                      value={h.bias}
                      min={-6}
                      max={6}
                      step={0.1}
                      onChange={(v) => updateHead(h.id, { bias: v })}
                      format={(v) => (v > 0 ? `+${v.toFixed(1)}` : v.toFixed(1))}
                      accent={headColor(i)}
                    />
                    <Slider
                      label="Температура"
                      value={h.temp}
                      min={0.3}
                      max={2.5}
                      step={0.05}
                      onChange={(v) => updateHead(h.id, { temp: v })}
                      format={(v) => `×${v.toFixed(2)}`}
                      accent={headColor(i)}
                    />
                  </div>
                </div>
              ))}
            </div>
            <p className="mt-3 text-[11px] leading-relaxed text-slate-500">
              <span className="text-slate-300">Bias</span> добавляет константу к логитам выбранного
              ключа — голова «прицеливается» в него.{" "}
              <span className="text-slate-300">Температура</span> усиливает или сглаживает
              распределение: логиты делятся на T, поэтому T &gt; 1 — площе, T &lt; 1 — резче.
            </p>
          </Card>
        </div>

        {/* --------------------------------- Рабочая область ------------------------------ */}
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-6">
            <Stat label="Голов" value={nHeads} color="#38bdf8" />
            <Stat label="d_head" value={result.dHead} color="#a78bfa" />
            <Stat label="Токенов" value={result.n} color="#4ade80" />
            <Stat
              label="Избыточность"
              value={`${Math.round(result.redundancy * 100)}%`}
              sub="схожесть голов"
              color="#fbbf24"
            />
            <Stat
              label="Эффективных голов"
              value={result.effectiveHeads.toFixed(1)}
              sub="после учёта дублирования"
              color="#fb7185"
            />
            <Stat
              label="Ср. энтропия"
              value={avgEntropy.toFixed(2)}
              sub={`макс ${Math.log(result.n).toFixed(2)}`}
              color="#22d3ee"
            />
          </div>

          <Card className="p-4 sm:p-5">
            <div className="mb-4 flex flex-wrap gap-1.5">
              {TABS.map((t) => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => setTab(t.id)}
                  className={cn(
                    "rounded-lg px-3 py-1.5 text-xs font-semibold transition",
                    tab === t.id
                      ? "bg-white/10 text-white"
                      : "text-slate-400 hover:bg-white/5 hover:text-slate-200"
                  )}
                >
                  {t.label}
                </button>
              ))}
            </div>

            {tab === "matrices" && (
              <div className="space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <p className="text-xs leading-relaxed text-slate-500">
                    Строки — запросы (Q), столбцы — ключи (K). Ячейка — вероятность внимания.
                    Нажмите на матрицу, чтобы выбрать голову и токен.
                  </p>
                  <div className="flex items-center gap-3">
                    <HeatLegend max={maxWeight} />
                    <GhostButton
                      onClick={() => {
                        const rows = head.weights
                          .map((r) => r.map((v) => v.toFixed(4)).join("\t"))
                          .join("\n");
                        const text = `tokens\t${tokens.join("\t")}\n` + rows;
                        navigator.clipboard?.writeText(text);
                      }}
                    >
                      ⧉ Скопировать TSV
                    </GhostButton>
                  </div>
                </div>
                <div className="grid gap-4 md:grid-cols-2">
                  {result.heads.map((h, i) => (
                    <div
                      key={h.id}
                      onClick={() => setSelectedHead(i)}
                      className={cn(
                        "cursor-pointer rounded-2xl border p-3 text-left transition",
                        i === selectedHead
                          ? "border-white/25 bg-white/[0.05]"
                          : "border-white/10 bg-slate-900/30 hover:border-white/20"
                      )}
                    >
                      <div className="mb-3 flex items-center gap-2">
                        <span className="h-2.5 w-2.5 rounded-full" style={{ background: headColor(i) }} />
                        <span className="text-sm font-semibold text-white">Голова {i + 1}</span>
                        <span className="ml-auto font-mono text-[10px] text-slate-500">
                          H̄ = {mean(h.entropy).toFixed(2)}
                        </span>
                      </div>
                      <Heatmap
                        matrix={h.weights}
                        rowLabels={tokens}
                        colLabels={tokens}
                        max={maxWeight}
                        onSelectRow={(ri) => {
                          setSelectedHead(i);
                          setSelectedToken(ri);
                        }}
                        selectedRow={i === selectedHead ? selectedToken : undefined}
                      />
                      <div className="mt-3 space-y-1 border-t border-white/10 pt-2">
                        <p className="text-[11px] leading-relaxed text-slate-400">
                          Чаще всего смотрит на{" "}
                          <span className="font-semibold text-white">
                            «{truncate(headInsight(i).token, 14)}»
                          </span>{" "}
                          — {(headInsight(i).avg * 100).toFixed(1)}% внимания в среднем (без учёта себя)
                        </p>
                        <p className="text-[10px] text-slate-600">
                          Фокус: {(headInsight(i).focus * 100).toFixed(0)}% · ср. энтропия{" "}
                          {mean(h.entropy).toFixed(2)} / {Math.log(result.n).toFixed(2)}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {tab === "flow" && (
              <div className="space-y-4">
                <div className="flex flex-wrap gap-1.5">
                  {result.heads.map((h, i) => (
                    <button
                      key={h.id}
                      type="button"
                      onClick={() => setSelectedHead(i)}
                      className={cn(
                        "rounded-lg border px-3 py-1.5 text-xs font-semibold transition",
                        i === selectedHead
                          ? "text-slate-950"
                          : "border-white/10 bg-white/5 text-slate-300 hover:bg-white/10"
                      )}
                      style={
                        i === selectedHead
                          ? { background: headColor(i), borderColor: headColor(i) }
                          : undefined
                      }
                    >
                      Голова {i + 1}
                    </button>
                  ))}
                </div>
                <div className="rounded-2xl border border-white/10 bg-slate-950/50 p-3">
                  <AttentionFlow weights={head.weights} tokens={tokens} headId={selectedHead} height={320} />
                </div>
                <div className="grid gap-3 sm:grid-cols-2">
                  <div className="rounded-xl border border-white/10 bg-slate-900/40 p-4">
                    <h4 className="mb-2 text-xs font-semibold uppercase tracking-wider text-slate-400">
                      Куда смотрит «{truncate(tokens[selectedToken] ?? "", 14)}»
                    </h4>
                    {tokens.map((t, j) => (
                      <div key={j} className="mb-1.5 flex items-center gap-2">
                        <span className="w-20 shrink-0 truncate text-[11px] text-slate-400" title={t}>
                          {truncate(t, 12)}
                        </span>
                        <div className="h-2 flex-1 overflow-hidden rounded-full bg-slate-800">
                          <div
                            className="h-full rounded-full"
                            style={{
                              width: `${(head.weights[selectedToken]?.[j] ?? 0) * 100}%`,
                              background: headColor(selectedHead),
                            }}
                          />
                        </div>
                        <span className="w-10 shrink-0 text-right font-mono text-[10px] text-slate-400">
                          {((head.weights[selectedToken]?.[j] ?? 0) * 100).toFixed(1)}%
                        </span>
                      </div>
                    ))}
                  </div>
                  <div className="rounded-xl border border-white/10 bg-slate-900/40 p-4 text-sm leading-relaxed text-slate-400">
                    <h4 className="mb-2 text-xs font-semibold uppercase tracking-wider text-slate-400">
                      Как читать диаграмму
                    </h4>
                    <p>
                      Внизу — запросы, вверху — ключи. Толщина дуги пропорциональна весу
                      внимания: чем толще связь, тем сильнее токен «смотрит» на другой.
                    </p>
                    <p className="mt-2">
                      Каждая голова рисует свой рисунок. Если две головы дают похожие дуги —
                      они избыточны и не дают пользы. Добавьте bias к разным токенам в разных
                      головах и посмотрите, как рисунки расходятся.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {tab === "vectors" && (
              <div className="space-y-4">
                <div>
                  <div className="mb-2 text-xs font-medium uppercase tracking-wider text-slate-500">
                    Токен-запрос
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {tokens.map((t, i) => (
                      <button
                        key={i}
                        type="button"
                        onClick={() => setSelectedToken(i)}
                        className={cn(
                          "rounded-lg border px-2.5 py-1.5 font-mono text-xs transition",
                          i === selectedToken
                            ? "border-sky-400/60 bg-sky-400/15 text-white"
                            : "border-white/10 bg-white/5 text-slate-300 hover:bg-white/10"
                        )}
                      >
                        {truncate(t, 12)}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="grid gap-4 md:grid-cols-3">
                  <div className="rounded-xl border border-white/10 bg-slate-900/40 p-3">
                    <VectorBars
                      values={head.Q[selectedToken]}
                      label="Q — запрос"
                      color="#38bdf8"
                    />
                  </div>
                  <div className="rounded-xl border border-white/10 bg-slate-900/40 p-3">
                    <VectorBars
                      values={head.K[selectedToken]}
                      label="K — ключ"
                      color="#fbbf24"
                    />
                  </div>
                  <div className="rounded-xl border border-white/10 bg-slate-900/40 p-3">
                    <VectorBars
                      values={head.V[selectedToken]}
                      label="V — значение"
                      color="#4ade80"
                    />
                  </div>
                </div>

                <div className="grid gap-4 lg:grid-cols-2">
                  <div className="rounded-xl border border-white/10 bg-slate-900/40 p-4">
                    <h4 className="mb-3 text-xs font-semibold uppercase tracking-wider text-slate-400">
                      Логиты: Q·K / √d_k → softmax
                    </h4>
                    {tokens.map((t, j) => {
                      const lg = head.logits[selectedToken][j];
                      const w = head.weights[selectedToken][j];
                      return (
                        <div key={j} className="mb-2 flex items-center gap-2">
                          <span className="w-20 shrink-0 truncate text-[11px] text-slate-400" title={t}>
                            {truncate(t, 12)}
                          </span>
                          <span className="w-14 shrink-0 text-right font-mono text-[10px] text-slate-500">
                            {isFinite(lg) ? fmt(lg) : "−∞"}
                          </span>
                          <div className="h-2 flex-1 overflow-hidden rounded-full bg-slate-800">
                            <div
                              className="h-full rounded-full"
                              style={{
                                width: `${w * 100}%`,
                                background: headColor(selectedHead),
                              }}
                            />
                          </div>
                          <span className="w-11 shrink-0 text-right font-mono text-[10px] text-slate-300">
                            {(w * 100).toFixed(1)}%
                          </span>
                        </div>
                      );
                    })}
                    <div className="mt-3 border-t border-white/10 pt-2 font-mono text-[11px] text-slate-500">
                      Σ весов = {head.weights[selectedToken].reduce((a, b) => a + b, 0).toFixed(4)}
                    </div>
                  </div>

                  <div className="rounded-xl border border-white/10 bg-slate-900/40 p-4">
                    <h4 className="mb-3 text-xs font-semibold uppercase tracking-wider text-slate-400">
                      Выход головы: Σ вес · V
                    </h4>
                    <VectorBars
                      values={head.out[selectedToken]}
                      label={`out[${truncate(tokens[selectedToken] ?? "", 10)}] · голова ${selectedHead + 1}`}
                      color={headColor(selectedHead)}
                      bars={16}
                    />
                    <p className="mt-3 text-[11px] leading-relaxed text-slate-500">
                      Каждый элемент выхода — взвешенная смесь значений V. Токены, получившие
                      большой вес, «вкладывают» своё значение в результат.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {tab === "output" && (
              <div className="space-y-4">
                <div className="grid gap-4 lg:grid-cols-2">
                  <div className="rounded-xl border border-white/10 bg-slate-900/40 p-4">
                    <h4 className="mb-1 text-xs font-semibold uppercase tracking-wider text-slate-400">
                      Конкатенация голов
                    </h4>
                    <p className="mb-3 text-[11px] text-slate-500">
                      Каждая голова даёт {result.dHead} измерений, всего {dModel}.
                    </p>
                    <div className="flex h-8 w-full overflow-hidden rounded-lg">
                      {result.heads.map((h, i) => (
                        <div
                          key={h.id}
                          className="flex items-center justify-center font-mono text-[10px] font-bold text-slate-950"
                          style={{ width: `${100 / result.heads.length}%`, background: headColor(i) }}
                          title={`Голова ${i + 1}`}
                        >
                          {i + 1}
                        </div>
                      ))}
                    </div>
                    <div className="mt-4">
                      <VectorBars
                        values={result.concat[selectedToken]}
                        label="Concat (до W^O)"
                        color="#a78bfa"
                        bars={16}
                      />
                    </div>
                  </div>

                  <div className="rounded-xl border border-white/10 bg-slate-900/40 p-4">
                    <h4 className="mb-1 text-xs font-semibold uppercase tracking-wider text-slate-400">
                      Финальный выход после W^O
                    </h4>
                    <p className="mb-3 text-[11px] text-slate-500">
                      Общая проекция смешивает информацию всех голов.
                    </p>
                    <VectorBars
                      values={result.output[selectedToken]}
                      label={`y[${truncate(tokens[selectedToken] ?? "", 10)}]`}
                      color="#38bdf8"
                      bars={16}
                    />
                  </div>
                </div>

                <div className="rounded-xl border border-white/10 bg-slate-900/40 p-4">
                  <h4 className="mb-3 text-xs font-semibold uppercase tracking-wider text-slate-400">
                    Multi-head vs одна голова: насколько различаются выходы
                  </h4>
                  <div className="grid gap-2 sm:grid-cols-2">
                    {outputSimilarity.map((c, i) => (
                      <div key={i} className="flex items-center gap-2">
                        <span className="w-24 shrink-0 truncate text-[11px] text-slate-400">
                          {truncate(tokens[i] ?? "", 12)}
                        </span>
                        <div className="h-2 flex-1 overflow-hidden rounded-full bg-slate-800">
                          <div
                            className="h-full rounded-full bg-gradient-to-r from-cyan-400 to-violet-400"
                            style={{ width: `${Math.max(0, c) * 100}%` }}
                          />
                        </div>
                        <span className="w-12 shrink-0 text-right font-mono text-[10px] text-slate-300">
                          {c.toFixed(3)}
                        </span>
                      </div>
                    ))}
                  </div>
                  <p className="mt-3 text-[11px] leading-relaxed text-slate-500">
                    Косинусная близость между выходом multi-head и выходом одной головы при той же
                    размерности модели. Значение близкое к 1 означает, что дополнительные головы
                    почти не добавили информации — либо веса слишком похожи, либо d_head слишком
                    велик и информации в каждой голове мало.
                  </p>
                </div>

                <div className="rounded-xl border border-white/10 bg-slate-900/40 p-4">
                  <h4 className="mb-3 text-xs font-semibold uppercase tracking-wider text-slate-400">
                    Матрица выходов Y = Concat · W^O
                  </h4>
                  <OutputTable matrix={result.output} tokens={tokens} selected={selectedToken} onSelect={setSelectedToken} />
                </div>

                <div className="rounded-xl border border-white/10 bg-slate-900/40 p-4">
                  <h4 className="mb-3 text-xs font-semibold uppercase tracking-wider text-slate-400">
                    Сравнение с одной головой (тот же текст и веса эмбеддингов)
                  </h4>
                  <div className="grid gap-4 md:grid-cols-2">
                    <div>
                      <div className="mb-2 flex items-center gap-2 text-[11px] font-semibold text-slate-300">
                        <span className="h-2.5 w-2.5 rounded-full bg-slate-400" /> одна голова
                      </div>
                      <Heatmap
                        matrix={single.heads[0].weights}
                        rowLabels={tokens}
                        colLabels={tokens}
                        max={maxWeight}
                        compact
                      />
                    </div>
                    <div>
                      <div className="mb-2 flex items-center gap-2 text-[11px] font-semibold text-slate-300">
                        <span className="h-2.5 w-2.5 rounded-full bg-sky-400" /> голова {selectedHead + 1} из {nHeads}
                      </div>
                      <Heatmap
                        matrix={head.weights}
                        rowLabels={tokens}
                        colLabels={tokens}
                        max={maxWeight}
                        compact
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}
          </Card>

          <div className="flex flex-wrap gap-2">
            <Badge color="#38bdf8">
              {scaled ? `scale = 1/√${result.dHead} = ${(1 / Math.sqrt(result.dHead)).toFixed(3)}` : "без масштабирования"}
            </Badge>
            <Badge color={causal ? "#fbbf24" : "#64748b"}>
              {causal ? "причинная маска включена" : "маска выключена (bidirectional)"}
            </Badge>
            <Badge color="#a78bfa">seed = {seed}</Badge>
            <Badge color="#4ade80">{tokens.length} токенов</Badge>
          </div>
        </div>
      </div>
    </section>
  );
}

function OutputTable({
  matrix,
  tokens,
  selected,
  onSelect,
}: {
  matrix: Mat;
  tokens: string[];
  selected: number;
  onSelect: (i: number) => void;
}) {
  const cols = Math.min(matrix[0]?.length ?? 0, 10);
  const absMax = Math.max(...matrix.flat().map((v) => Math.abs(v)), 1e-9);
  return (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse text-[10px]">
        <thead>
          <tr>
            <th className="px-2 py-1 text-left font-medium text-slate-500">токен</th>
            {Array.from({ length: cols }, (_, j) => (
              <th key={j} className="px-2 py-1 text-right font-medium text-slate-500">
                d{j}
              </th>
            ))}
            {matrix[0] && matrix[0].length > cols && (
              <th className="px-2 py-1 text-right font-medium text-slate-500">…</th>
            )}
          </tr>
        </thead>
        <tbody className="font-mono">
          {matrix.map((row, i) => (
            <tr
              key={i}
              onClick={() => onSelect(i)}
              className={cn(
                "cursor-pointer border-t border-white/5 transition",
                i === selected ? "bg-sky-400/10" : "hover:bg-white/5"
              )}
            >
              <td className="max-w-[110px] truncate px-2 py-1.5 text-left text-slate-300">
                {truncate(tokens[i] ?? "", 12)}
              </td>
              {row.slice(0, cols).map((v, j) => (
                <td
                  key={j}
                  className="px-2 py-1.5 text-right"
                  style={{
                    color: v >= 0 ? "#7dd3fc" : "#f9a8d4",
                    opacity: 0.45 + (Math.abs(v) / absMax) * 0.55,
                  }}
                >
                  {v.toFixed(2)}
                </td>
              ))}
              {matrix[0] && matrix[0].length > cols && (
                <td className="px-2 py-1.5 text-right text-slate-600">…</td>
              )}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
