import { cn } from "../utils/cn";
import { heatColor, heatTextColor, truncate, type Mat } from "../lib/attention";

export function Heatmap({
  matrix,
  rowLabels,
  colLabels,
  color,
  selectedRow,
  onSelectRow,
  onSelectCell,
  max,
  compact,
  highlightCol,
}: {
  matrix: Mat;
  rowLabels: string[];
  colLabels: string[];
  color?: string;
  selectedRow?: number;
  onSelectRow?: (i: number) => void;
  onSelectCell?: (i: number, j: number) => void;
  max?: number;
  compact?: boolean;
  highlightCol?: number;
}) {
  const n = matrix.length;
  if (!n) return null;
  const m = matrix[0].length;
  const mx = max ?? Math.max(...matrix.flat().map((v) => (isFinite(v) ? v : 0)), 1e-9);

  const cell = (i: number, j: number) => {
    const raw = matrix[i][j];
    const v = isFinite(raw) ? raw : 0;
    const norm = Math.max(0, Math.min(1, v / mx));
    const bg = color ?? heatColor(norm);
    return (
      <button
        type="button"
        key={`${i}-${j}`}
        onClick={() => {
          onSelectCell?.(i, j);
          onSelectRow?.(i);
        }}
        title={`запрос «${rowLabels[i]}» → ключ «${colLabels[j]}» : ${raw.toFixed(4)}`}
        className={cn(
          "relative flex items-center justify-center rounded-[5px] font-mono text-[9px] transition hover:z-10 hover:ring-2 hover:ring-white/70",
          compact ? "h-6 w-6" : "h-9 w-9"
        )}
        style={{ background: bg, color: heatTextColor(norm) }}
      >
        {!compact && isFinite(raw) ? raw.toFixed(2) : ""}
        {highlightCol === j && (
          <span className="pointer-events-none absolute inset-0 rounded-[5px] ring-1 ring-inset ring-white/80" />
        )}
      </button>
    );
  };

  return (
    <div className="overflow-x-auto">
      <div
        className="grid gap-1"
        style={{ gridTemplateColumns: `minmax(46px, auto) repeat(${m}, minmax(26px, 1fr))` }}
      >
        <div />
        {colLabels.map((c, j) => (
          <div key={`h${j}`} className="flex flex-col items-center gap-1">
            <span
              className="max-w-[70px] truncate text-[10px] font-medium text-slate-400"
              title={c}
            >
              {truncate(c, 8)}
            </span>
          </div>
        ))}
        {rowLabels.map((r, i) => (
          <div key={`r${i}`} className="contents">
            <button
              type="button"
              onClick={() => onSelectRow?.(i)}
              className={cn(
                "flex items-center justify-end pr-2 text-right text-[10px] font-medium transition",
                selectedRow === i ? "text-sky-300" : "text-slate-500 hover:text-slate-300"
              )}
              title={r}
            >
              <span className="max-w-[70px] truncate">{truncate(r, 8)}</span>
            </button>
            {matrix[i].map((_, j) => (
              <div key={`${i}-${j}`} className="contents">
                {cell(i, j)}
              </div>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}

export function HeatLegend({ max, label = "вес внимания" }: { max: number; label?: string }) {
  const stops = Array.from({ length: 12 }, (_, i) => heatColor(i / 11));
  return (
    <div className="flex items-center gap-2">
      <span className="text-[10px] text-slate-500">0</span>
      <div
        className="h-2 w-24 rounded-full"
        style={{ background: `linear-gradient(to right, ${stops.join(",")})` }}
      />
      <span className="font-mono text-[10px] text-slate-400">{max.toFixed(2)}</span>
      <span className="text-[10px] text-slate-600">{label}</span>
    </div>
  );
}
