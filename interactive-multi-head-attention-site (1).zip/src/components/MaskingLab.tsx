import { useMemo } from "react";
import type { Lab } from "../lib/lab";
import { computeAttn, headColor } from "../lib/attention";
import { Card, GhostButton, SectionTitle } from "./ui";
import { cn } from "../utils/cn";

export function MaskingLab({ lab }: { lab: Lab }) {
  const { tokens, config, setCausal, causal } = lab;

  const free = useMemo(() => computeAttn({ ...config, causal: false }), [config]);
  const masked = useMemo(() => computeAttn({ ...config, causal: true }), [config]);

  const last = tokens.length - 1;
  const headFree = free.heads[0];
  const headMasked = masked.heads[0];

  const maskRows = tokens.map((_, i) => tokens.map((__, j) => (causal ? j <= i : true)));

  return (
    <section id="masking" className="relative mx-auto max-w-7xl px-4 py-20 sm:px-6 sm:py-24">
      <SectionTitle
        eyebrow="Маски"
        title="Причинная маска: как модель «не подглядывает»"
        subtitle="В генеративных моделях токен не должен видеть будущее. Маска обнуляет логиты для j > i, поэтому после softmax вся вероятность распределяется только по прошлому контексту."
        icon={
          <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth={2.2}>
            <rect x="4" y="10" width="16" height="10" rx="2" />
            <path d="M8 10V7a4 4 0 0 1 8 0v3" />
          </svg>
        }
      />

      <div className="grid gap-4 lg:grid-cols-[1fr_1fr]">
        <Card className="p-5">
          <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
            <h3 className="text-sm font-semibold text-white">Матрица маски</h3>
            <GhostButton onClick={() => setCausal(!causal)}>
              {causal ? "Выключить маску" : "Включить маску"}
            </GhostButton>
          </div>
          <div className="overflow-x-auto">
            <div
              className="grid gap-1"
              style={{ gridTemplateColumns: `minmax(60px, auto) repeat(${tokens.length}, minmax(24px, 1fr))` }}
            >
              <div />
              {tokens.map((_, j) => (
                <div key={j} className="truncate text-center text-[9px] text-slate-500">
                  {j + 1}
                </div>
              ))}
              {maskRows.map((row, i) => (
                <div key={i} className="contents">
                  <div className="truncate pr-2 text-right text-[9px] text-slate-500">{i + 1}</div>
                  {row.map((allowed, j) => (
                    <div
                      key={j}
                      className={cn(
                        "flex h-7 items-center justify-center rounded text-[9px]",
                        allowed ? "bg-sky-400/25 text-sky-200" : "bg-white/5 text-slate-600"
                      )}
                      title={allowed ? "разрешено" : "замаскировано (−∞)"}
                    >
                      {allowed ? "✓" : "×"}
                    </div>
                  ))}
                </div>
              ))}
            </div>
          </div>
          <p className="mt-3 text-xs leading-relaxed text-slate-500">
            {causal
              ? "Сейчас включена причинная маска: нижний треугольник разрешён, верхний — замаскирован."
              : "Сейчас маска выключена: каждый токен видит весь контекст (как в encoder-моделях, например BERT)."}
          </p>
        </Card>

        <Card className="p-5">
          <h3 className="mb-1 text-sm font-semibold text-white">
            Внимание последнего токена: «{tokens[last]}»
          </h3>
          <p className="mb-4 text-xs leading-relaxed text-slate-500">
            Слева — без маски, справа — с маской. Обратите внимание: без маски последний токен
            «видит» весь текст, с маской — только то, что было до него.
          </p>
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <div className="mb-2 text-[11px] font-semibold text-slate-300">Без маски</div>
              {tokens.map((t, j) => (
                <div key={j} className="mb-1.5 flex items-center gap-2">
                  <span className="w-20 shrink-0 truncate text-[11px] text-slate-400">{t}</span>
                  <div className="h-2 flex-1 overflow-hidden rounded-full bg-slate-800">
                    <div
                      className="h-full rounded-full bg-slate-400"
                      style={{ width: `${headFree.weights[last][j] * 100}%` }}
                    />
                  </div>
                  <span className="w-10 shrink-0 text-right font-mono text-[10px] text-slate-400">
                    {(headFree.weights[last][j] * 100).toFixed(1)}%
                  </span>
                </div>
              ))}
            </div>
            <div>
              <div className="mb-2 text-[11px] font-semibold text-slate-300">С причинной маской</div>
              {tokens.map((t, j) => (
                <div key={j} className="mb-1.5 flex items-center gap-2">
                  <span className="w-20 shrink-0 truncate text-[11px] text-slate-400">{t}</span>
                  <div className="h-2 flex-1 overflow-hidden rounded-full bg-slate-800">
                    <div
                      className="h-full rounded-full"
                      style={{
                        width: `${headMasked.weights[last][j] * 100}%`,
                        background: headColor(0),
                      }}
                    />
                  </div>
                  <span className="w-10 shrink-0 text-right font-mono text-[10px] text-slate-400">
                    {(headMasked.weights[last][j] * 100).toFixed(1)}%
                  </span>
                </div>
              ))}
            </div>
          </div>
          <div className="mt-4 rounded-xl border border-white/10 bg-slate-900/50 p-3 text-xs leading-relaxed text-slate-400">
            Реализация в коде — одна строка: <code className="font-mono text-sky-300">mask = torch.triu(torch.ones(L, L) * -inf, diagonal=1)</code>.
            Замаскированные ячейки получают −∞ до softmax, поэтому их вероятность строго нулевая.
          </div>
        </Card>
      </div>

      <div className="mt-4 grid gap-4 md:grid-cols-3">
        {[
          {
            t: "Encoder (BERT)",
            d: "Маска не нужна: задача — понять весь текст сразу. Каждый токен видит все токены. Но такой модели нельзя просто дописать текст и получить продолжение.",
            c: "#4ade80",
          },
          {
            t: "Decoder (GPT)",
            d: "Используется причинная маска: при генерации модель формирует следующий токен только на основе прошлого. Это делает обучение параллельным, а генерацию — последовательной.",
            c: "#fbbf24",
          },
          {
            t: "Padding mask",
            d: "Ещё один тип маски: скрывает «пустые» позиции паддинга, чтобы модель не обращала на них внимания. Часто комбинируется с причинной маской.",
            c: "#a78bfa",
          },
        ].map((x) => (
          <Card key={x.t} className="p-5" glow={x.c}>
            <h4 className="text-sm font-semibold" style={{ color: x.c }}>
              {x.t}
            </h4>
            <p className="mt-2 text-sm leading-relaxed text-slate-400">{x.d}</p>
          </Card>
        ))}
      </div>
    </section>
  );
}
