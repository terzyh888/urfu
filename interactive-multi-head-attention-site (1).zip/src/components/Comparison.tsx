import { useMemo } from "react";
import type { Lab } from "../lib/lab";
import { computeAttn } from "../lib/attention";
import { defaultHeads } from "../lib/lab";
import { Heatmap } from "./Heatmap";
import { Card, SectionTitle, Stat } from "./ui";
import { cn } from "../utils/cn";

export function Comparison({ lab }: { lab: Lab }) {
  const { result, single, tokens, config } = lab;

  /* чистый эксперимент: одинаковые веса эмбеддингов, разное число голов */
  const rows = useMemo(() => {
    return [1, 2, 4, 8].map((h) => {
      const cfg = {
        ...config,
        nHeads: h,
        heads: defaultHeads(h).map((x) => ({ ...x, target: 0 })),
      };
      const r = computeAttn(cfg);
      const s = computeAttn({ ...cfg, nHeads: 1, heads: [{ id: 0, target: 0, bias: 0, temp: 1 }] });
      let sim = 0;
      for (let i = 0; i < r.n; i++) {
        let d = 0;
        let na = 0;
        let nb = 0;
        for (let j = 0; j < r.output[i].length; j++) {
          d += r.output[i][j] * s.output[i][j];
          na += r.output[i][j] ** 2;
          nb += s.output[i][j] ** 2;
        }
        sim += na && nb ? d / (Math.sqrt(na) * Math.sqrt(nb)) : 0;
      }
      return {
        heads: h,
        dHead: r.dHead,
        redundancy: r.redundancy,
        effective: r.effectiveHeads,
        outSim: sim / r.n,
        diversity: 1 - r.redundancy,
      };
    });
  }, [config]);

  return (
    <section id="compare" className="relative mx-auto max-w-7xl px-4 py-20 sm:px-6 sm:py-24">
      <SectionTitle
        eyebrow="Сравнение"
        title="Одна голова против нескольких"
        subtitle="Чем больше голов — тем тоньше «оптика» каждой и тем выше шанс, что головы смотрят на разное. Но если головы выучили одно и то же, дополнительная ёмкость тратится впустую."
        icon={
          <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth={2.2}>
            <path d="M4 18V6M9 18V9M14 18v-4M19 18V4" />
          </svg>
        }
      />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Stat label="Голов сейчас" value={result.heads.length} color="#38bdf8" />
        <Stat
          label="Средняя схожесть голов"
          value={`${Math.round(result.redundancy * 100)}%`}
          sub="1 = полное дублирование"
          color="#fbbf24"
        />
        <Stat
          label="Эффективных голов"
          value={result.effectiveHeads.toFixed(2)}
          sub="после учёта дублирования"
          color="#4ade80"
        />
        <Stat
          label="Разнообразие"
          value={`${Math.round((1 - result.redundancy) * 100)}%`}
          sub="1 − схожесть"
          color="#a78bfa"
        />
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-[1fr_1fr]">
        <Card className="p-5">
          <h3 className="mb-1 text-sm font-semibold text-white">Матрица схожести голов</h3>
          <p className="mb-4 text-xs leading-relaxed text-slate-500">
            Каждая ячейка — косинусная близость двух матриц внимания (как «схожие картинки»).
            Диагональ всегда 1. Близкие к единице значения означают, что головы дублируют друг
            друга.
          </p>
          <div className="overflow-x-auto">
            <div
              className="grid gap-1"
              style={{
                gridTemplateColumns: `minmax(52px, auto) repeat(${result.heads.length}, minmax(30px, 1fr))`,
              }}
            >
              <div />
              {result.heads.map((_, j) => (
                <div key={j} className="text-center font-mono text-[10px] text-slate-500">
                  {j + 1}
                </div>
              ))}
              {result.heads.map((_, i) => (
                <div key={i} className="contents">
                  <div className="pr-2 text-right font-mono text-[10px] text-slate-500">{i + 1}</div>
                  {result.similarity[i].map((v, j) => (
                    <div
                      key={j}
                      title={`схожесть голов ${i + 1} и ${j + 1}: ${v.toFixed(3)}`}
                      className="flex h-8 items-center justify-center rounded-md font-mono text-[10px]"
                      style={{
                        background: `hsl(${205 - 185 * Math.max(0, v)} 80% ${17 + 50 * Math.max(0, v)}%)`,
                        color: v > 0.55 ? "#0b1220" : "#cbd5e1",
                      }}
                    >
                      {v.toFixed(2)}
                    </div>
                  ))}
                </div>
              ))}
            </div>
          </div>
        </Card>

        <Card className="p-5">
          <h3 className="mb-1 text-sm font-semibold text-white">Внимание: одна голова vs текущая</h3>
          <p className="mb-4 text-xs leading-relaxed text-slate-500">
            Слева — как выглядит единственная голова на всю модель, справа — выбранная голова из
            текущей конфигурации. Обратите внимание: одна голова вынуждена «сглаживать» всё сразу.
          </p>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <div className="mb-2 text-[11px] font-semibold text-slate-300">Одна голова</div>
              <Heatmap matrix={single.heads[0].weights} rowLabels={tokens} colLabels={tokens} compact />
            </div>
            <div>
              <div className="mb-2 text-[11px] font-semibold text-slate-300">Голова 1 из {result.heads.length}</div>
              <Heatmap
                matrix={result.heads[0].weights}
                rowLabels={tokens}
                colLabels={tokens}
                compact
              />
            </div>
          </div>
          <div className="mt-4 rounded-xl border border-amber-400/20 bg-amber-400/[0.06] p-3 text-xs leading-relaxed text-amber-200/90">
            Попробуйте в песочнице задать разные <span className="font-semibold">bias</span> для разных
            голов — матрица схожести сразу станет разнообразнее, а выход модели заметно изменится.
          </div>
        </Card>
      </div>

      <Card className="mt-4 overflow-hidden p-0">
        <div className="border-b border-white/10 px-5 py-4">
          <h3 className="text-sm font-semibold text-white">Эксперимент: сколько голов нужно?</h3>
          <p className="mt-1 text-xs leading-relaxed text-slate-500">
            Один и тот же текст и зерно весов, меняется только число голов (без индивидуальных
            смещений). Показана избыточность и насколько выход отличается от выхода одной головы.
          </p>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[640px] text-left text-xs">
            <thead className="bg-white/[0.03] text-slate-400">
              <tr>
                <th className="px-5 py-3 font-medium">Голов</th>
                <th className="px-3 py-3 font-medium">d_head</th>
                <th className="px-3 py-3 font-medium">Избыточность</th>
                <th className="px-3 py-3 font-medium">Разнообразие</th>
                <th className="px-3 py-3 font-medium">Эффективных голов</th>
                <th className="px-3 py-3 font-medium">Отличие выхода от 1 головы</th>
              </tr>
            </thead>
            <tbody className="font-mono">
              {rows.map((r) => (
                <tr
                  key={r.heads}
                  className={cn(
                    "border-t border-white/5 transition",
                    r.heads === result.heads.length ? "bg-sky-400/[0.07]" : "hover:bg-white/5"
                  )}
                >
                  <td className="px-5 py-3 text-slate-200">
                    {r.heads}
                    {r.heads === result.heads.length && (
                      <span className="ml-2 rounded bg-sky-400/20 px-1.5 py-0.5 text-[9px] font-sans text-sky-300">
                        сейчас
                      </span>
                    )}
                  </td>
                  <td className="px-3 py-3 text-slate-400">{r.dHead}</td>
                  <td className="px-3 py-3" style={{ color: r.redundancy > 0.9 ? "#fb7185" : "#7dd3fc" }}>
                    {(r.redundancy * 100).toFixed(1)}%
                  </td>
                  <td className="px-3 py-3 text-emerald-300">{(r.diversity * 100).toFixed(1)}%</td>
                  <td className="px-3 py-3 text-slate-300">{r.effective.toFixed(2)}</td>
                  <td className="px-3 py-3 text-violet-300">{(1 - r.outSim).toFixed(3)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </section>
  );
}
