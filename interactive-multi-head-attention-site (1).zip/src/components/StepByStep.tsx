import type { Lab } from "../lib/lab";
import { buildEmbeddings, fmt, headColor, truncate } from "../lib/attention";
import { VectorBars } from "./VectorBars";
import { Card, SectionTitle } from "./ui";

export function StepByStep({ lab }: { lab: Lab }) {
  const { result, selectedHead, selectedToken, tokens, scaled } = lab;
  const head = result.heads[Math.min(selectedHead, result.heads.length - 1)];
  const color = headColor(selectedHead);
  const tok = tokens[selectedToken] ?? "";
  const embeddings = buildEmbeddings(tokens, lab.dModel, lab.seed);

  const steps = [
    {
      n: 1,
      title: "Вход: эмбеддинги токенов X",
      formula: "X ∈ ℝ^{n×d_model}",
      body: "Каждый токен превращается в вектор из d_model чисел. В реальной модели это выход эмбеддинг-слоя (WordPiece, BPE, токенизатор). Здесь векторы синтезированы детерминированно, но сохраняют два свойства: одинаковые слова дают похожие векторы, а позиция добавляет свой вклад.",
      render: (
        <div className="grid gap-3 md:grid-cols-2">
          <div className="rounded-xl border border-white/10 bg-slate-900/50 p-3">
            <VectorBars
              values={embeddings[selectedToken]}
              label={`X[«${truncate(tok, 10)}»] — эмбеддинг токена`}
              color="#64748b"
              bars={12}
            />
          </div>
          <div className="rounded-xl border border-white/10 bg-slate-900/50 p-3">
            <div className="mb-2 text-xs font-semibold uppercase tracking-wider text-slate-400">
              Матрица X целиком
            </div>
            <div className="space-y-1">
              {embeddings.map((v, i) => (
                <div key={i} className="flex items-center gap-2">
                  <span className="w-16 shrink-0 truncate text-[10px] text-slate-500">
                    {truncate(tokens[i] ?? "", 10)}
                  </span>
                  <div className="flex flex-1 gap-px">
                    {v.slice(0, 16).map((x, j) => (
                      <div
                        key={j}
                        title={`d${j} = ${x.toFixed(3)}`}
                        className="h-4 flex-1 rounded-[2px]"
                        style={{
                          background: x >= 0 ? `rgba(56,189,248,${Math.min(1, Math.abs(x) / 2)})` : `rgba(244,114,182,${Math.min(1, Math.abs(x) / 2)})`,
                        }}
                      />
                    ))}
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-2 font-mono text-[10px] text-slate-500">
              n = {result.n} токенов, d_model = {result.config.dModel} (показаны первые 16 измерений)
            </div>
          </div>
        </div>
      ),
    },
    {
      n: 2,
      title: "Проекции Q, K, V",
      formula: "Q = X·W_Q,  K = X·W_K,  V = X·W_V",
      body: "Каждая голова имеет СВОИ матрицы проекций размером d_model × d_head. Поэтому головы видят текст в разных подпространствах — это источник специализации.",
      render: (
        <div className="grid gap-3 md:grid-cols-3">
          <div className="rounded-xl border border-white/10 bg-slate-900/50 p-3">
            <VectorBars values={head.Q[selectedToken]} label={`Q[«${truncate(tok, 10)}»]`} color="#38bdf8" bars={10} />
          </div>
          <div className="rounded-xl border border-white/10 bg-slate-900/50 p-3">
            <VectorBars values={head.K[selectedToken]} label={`K[«${truncate(tok, 10)}»]`} color="#fbbf24" bars={10} />
          </div>
          <div className="rounded-xl border border-white/10 bg-slate-900/50 p-3">
            <VectorBars values={head.V[selectedToken]} label={`V[«${truncate(tok, 10)}»]`} color="#4ade80" bars={10} />
          </div>
        </div>
      ),
    },
    {
      n: 3,
      title: "Скалярные произведения и масштабирование",
      formula: "S = Q·Kᵀ / √d_k",
      body: "Каждая пара (запрос, ключ) даёт одно число — насколько сильно «запрос смотрит» на «ключ». Деление на √d_k нужно, чтобы при больших d_k скалярные произведения не вырастали, и softmax не превращался в «всё или ничего».",
      render: (
        <div className="rounded-xl border border-white/10 bg-slate-900/50 p-4">
          <div className="grid gap-1.5 sm:grid-cols-2">
            {tokens.map((t, j) => (
              <div key={j} className="flex items-center gap-2">
                <span className="w-24 shrink-0 truncate text-[11px] text-slate-400">
                  {truncate(t, 12)}
                </span>
                <span className="w-16 shrink-0 text-right font-mono text-[10px] text-slate-300">
                  {fmt(head.logits[selectedToken][j], 3)}
                </span>
                <span className="font-mono text-[10px] text-slate-600">
                  = {fmt(head.Q[selectedToken].reduce((acc, v, k) => acc + v * head.K[j][k], 0), 2)}
                  {scaled ? ` / ${Math.sqrt(result.dHead).toFixed(2)}` : ""}
                </span>
              </div>
            ))}
          </div>
        </div>
      ),
    },
    {
      n: 4,
      title: "Softmax: превращаем оценки в вероятности",
      formula: "A = softmax(S)",
      body: "Softmax нормализует строку: все веса неотрицательны и в сумме дают 1. Каждая строка A — это распределение внимания одного токена по всем ключам.",
      render: (
        <div className="rounded-xl border border-white/10 bg-slate-900/50 p-4">
          {tokens.map((t, j) => {
            const w = head.weights[selectedToken][j];
            return (
              <div key={j} className="mb-1.5 flex items-center gap-2">
                <span className="w-24 shrink-0 truncate text-[11px] text-slate-400">{truncate(t, 12)}</span>
                <div className="h-2.5 flex-1 overflow-hidden rounded-full bg-slate-800">
                  <div className="h-full rounded-full" style={{ width: `${w * 100}%`, background: color }} />
                </div>
                <span className="w-12 shrink-0 text-right font-mono text-[10px] text-slate-300">
                  {w.toFixed(4)}
                </span>
              </div>
            );
          })}
        </div>
      ),
    },
    {
      n: 5,
      title: "Взвешенная сумма, конкатенация и W^O",
      formula: "head = A·V;  MultiHead = Concat(head₁…headₕ)·W^O",
      body: "Выход головы — смесь значений V, в которой вес каждого токена равен его вниманию. Головы склеиваются в один вектор длины d_model и пропускаются через общую проекцию W^O, чтобы головы могли «общаться» друг с другом.",
      render: (
        <div className="grid gap-3 md:grid-cols-2">
          <div className="rounded-xl border border-white/10 bg-slate-900/50 p-3">
            <VectorBars
              values={head.out[selectedToken]}
              label={`выход головы ${selectedHead + 1}`}
              color={color}
              bars={12}
            />
          </div>
          <div className="rounded-xl border border-white/10 bg-slate-900/50 p-3">
            <VectorBars
              values={result.output[selectedToken]}
              label="итоговый y после W^O"
              color="#38bdf8"
              bars={12}
            />
          </div>
        </div>
      ),
    },
  ];

  return (
    <section id="steps" className="relative mx-auto max-w-7xl px-4 py-20 sm:px-6 sm:py-24">
      <SectionTitle
        eyebrow="Пошагово"
        title="От текста к формуле: 5 шагов вычисления"
        subtitle="Все значения ниже — реальные числа из песочницы для выбранной головы и токена. Меняйте настройки в песочнице и возвращайтесь сюда."
        icon={
          <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth={2.2}>
            <path d="M4 6h16M4 12h10M4 18h6" />
          </svg>
        }
      />

      <div className="relative">
        <div className="absolute left-[19px] top-2 bottom-2 w-px bg-gradient-to-b from-sky-400/60 via-violet-400/30 to-transparent md:left-[27px]" />
        <div className="space-y-5">
          {steps.map((s) => (
            <div key={s.n} className="relative flex gap-4 md:gap-6">
              <div className="z-10 flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-white/15 bg-slate-900 font-mono text-sm font-bold text-sky-300 shadow-lg shadow-sky-500/10 md:h-14 md:w-14 md:text-base">
                {s.n}
              </div>
              <Card className="flex-1 p-5">
                <div className="mb-1 flex flex-wrap items-baseline gap-x-3">
                  <h3 className="text-base font-bold text-white md:text-lg">{s.title}</h3>
                  <code className="rounded-md bg-sky-400/10 px-2 py-0.5 font-mono text-[11px] text-sky-300">
                    {s.formula}
                  </code>
                </div>
                <p className="mb-4 text-sm leading-relaxed text-slate-400">{s.body}</p>
                {s.render}
              </Card>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-8 grid gap-4 md:grid-cols-2">
        <Card className="p-5" glow="#38bdf8">
          <h4 className="font-semibold text-white">Почему делят на √d_k?</h4>
          <p className="mt-2 text-sm leading-relaxed text-slate-400">
            Если компоненты Q и K независимы и имеют распределение ~N(0, 1), то их скалярное
            произведение имеет среднее 0 и дисперсию d_k, то есть стандартное отклонение √d_k.
            При d_k = 64 логиты легко достигают ±8…±20. Softmax на таких значениях вырождается: почти вся
            вероятность схлопывается на один токен, остальные теряют градиент. Деление на √d_k
            возвращает логиты к единичному масштабу и сохраняет «мягкое» распределение.
          </p>
        </Card>
        <Card className="p-5" glow="#a78bfa">
          <h4 className="font-semibold text-white">Что именно даёт multi-head?</h4>
          <p className="mt-2 text-sm leading-relaxed text-slate-400">
            Одна голова с d_head = d_model вынуждена решать все задачи одним набором фильтров.
            Несколько голов делят ёмкость: d_model = h · d_head. Каждая голова получает
            «собственную оптику», а конкатенация собирает разнородные признаки в один вектор.
            Общая матрица W^O после конкатенации позволяет смешивать информацию разных голов.
          </p>
        </Card>
      </div>
    </section>
  );
}
