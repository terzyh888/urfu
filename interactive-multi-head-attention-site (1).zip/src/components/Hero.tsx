import { PrimaryButton } from "./ui";

const TOKENS = ["Кот", "сидит", "на", "окне", "и", "смотрит"];

export function Hero() {
  return (
    <section id="top" className="relative overflow-hidden pt-28 pb-16 sm:pt-36 sm:pb-24">
      {/* фон */}
      <div className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute left-1/2 top-[-10rem] h-[32rem] w-[52rem] -translate-x-1/2 rounded-full bg-sky-500/20 blur-[120px]" />
        <div className="absolute right-[-8rem] top-32 h-96 w-96 rounded-full bg-violet-600/20 blur-[100px]" />
        <div className="absolute left-[-6rem] bottom-0 h-72 w-72 rounded-full bg-cyan-500/10 blur-[90px]" />
        <div
          className="absolute inset-0 opacity-[0.06]"
          style={{
            backgroundImage:
              "linear-gradient(to right, #94a3b8 1px, transparent 1px), linear-gradient(to bottom, #94a3b8 1px, transparent 1px)",
            backgroundSize: "56px 56px",
            maskImage: "radial-gradient(ellipse at 50% 0%, black 20%, transparent 75%)",
          }}
        />
      </div>

      <div className="mx-auto grid max-w-7xl items-center gap-12 px-4 sm:px-6 lg:grid-cols-[1.05fr_1fr]">
        <div>
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-sky-400/30 bg-sky-400/10 px-3.5 py-1.5 text-xs font-semibold text-sky-300">
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-sky-400" />
            Интерактивный учебник · Transformer · 2017
          </div>

          <h1 className="text-4xl font-extrabold leading-[1.05] tracking-tight text-white sm:text-6xl">
            Multi-Head
            <span className="block bg-gradient-to-r from-sky-400 via-cyan-300 to-violet-400 bg-clip-text text-transparent">
              Attention
            </span>
          </h1>

          <p className="mt-6 max-w-xl text-base leading-relaxed text-slate-400 sm:text-lg">
            Механизм, который позволяет модели смотреть на несколько частей контекста
            одновременно. Меняйте число голов, их настройки и текст — и наблюдайте,
            как меняются вычисления, матрицы внимания и итоговый выход.
          </p>

          <div className="mt-8 flex flex-wrap items-center gap-3">
            <PrimaryButton href="#playground">
              Запустить песочницу
              <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth={2.4}>
                <path d="M5 12h14M13 6l6 6-6 6" />
              </svg>
            </PrimaryButton>
            <a
              href="#steps"
              className="inline-flex items-center gap-2 rounded-xl border border-white/15 bg-white/5 px-5 py-3 text-sm font-semibold text-slate-200 transition hover:border-white/30 hover:bg-white/10"
            >
              Разобрать формулу по шагам
            </a>
          </div>

          <div className="mt-10 grid max-w-lg grid-cols-3 gap-3">
            {[
              { k: "8", v: "голов в базовой модели", c: "#38bdf8" },
              { k: "O(n²)", v: "стоимость внимания", c: "#a78bfa" },
              { k: "1", v: "конкатенация + W^O", c: "#fbbf24" },
            ].map((s) => (
              <div key={s.v} className="rounded-xl border border-white/10 bg-white/[0.03] px-3 py-3">
                <div className="font-mono text-xl font-bold" style={{ color: s.c }}>
                  {s.k}
                </div>
                <div className="mt-1 text-[11px] leading-tight text-slate-500">{s.v}</div>
              </div>
            ))}
          </div>
        </div>

        {/* мини-визуализация */}
        <div className="relative">
          <div className="animate-float-slow rounded-3xl border border-white/10 bg-white/[0.04] p-5 backdrop-blur-xl sm:p-6">
            <div className="mb-4 flex items-center justify-between">
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                Attention в реальном времени
              </span>
              <span className="flex items-center gap-1.5 text-[11px] text-emerald-400">
                <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-400" />
                live
              </span>
            </div>

            <svg viewBox="0 0 460 300" className="w-full">
              <defs>
                <linearGradient id="heroG" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0%" stopColor="#38bdf8" />
                  <stop offset="100%" stopColor="#a78bfa" />
                </linearGradient>
              </defs>

              {TOKENS.map((_, j) =>
                TOKENS.map((__, i) => {
                  const w = 0.12 + 0.5 * Math.abs(Math.sin((i + 1) * (j + 2) * 0.7));
                  const x1 = 40 + (i * 380) / (TOKENS.length - 1);
                  const x2 = 40 + (j * 380) / (TOKENS.length - 1);
                  const y1 = 236;
                  const y2 = 64;
                  return (
                    <path
                      key={`${i}-${j}`}
                      d={`M ${x1} ${y1} Q ${(x1 + x2) / 2} ${(y1 + y2) / 2 - 34} ${x2} ${y2}`}
                      fill="none"
                      stroke="url(#heroG)"
                      strokeWidth={1 + w * 8}
                      strokeOpacity={0.06 + w * 0.35}
                      strokeLinecap="round"
                    >
                      <animate
                        attributeName="stroke-opacity"
                        values={`${0.04 + w * 0.2};${0.25 + w * 0.6};${0.04 + w * 0.2}`}
                        dur={`${3 + ((i + j) % 4) * 0.7}s`}
                        repeatCount="indefinite"
                      />
                    </path>
                  );
                })
              )}

              {TOKENS.map((t, i) => {
                const x = 40 + (i * 380) / (TOKENS.length - 1);
                return (
                  <g key={t}>
                    <circle cx={x} cy={64} r={15} fill="#0b1220" stroke="#38bdf8" strokeWidth={1.8} />
                    <circle cx={x} cy={236} r={15} fill="#0b1220" stroke="#a78bfa" strokeWidth={1.8} />
                    <text x={x} y={68} textAnchor="middle" fontSize={10} fill="#7dd3fc" fontFamily="JetBrains Mono, monospace">
                      {i + 1}
                    </text>
                    <text x={x} y={240} textAnchor="middle" fontSize={10} fill="#c4b5fd" fontFamily="JetBrains Mono, monospace">
                      {i + 1}
                    </text>
                    <text x={x} y={38} textAnchor="middle" fontSize={11} fill="#94a3b8">
                      {t}
                    </text>
                    <text x={x} y={272} textAnchor="middle" fontSize={11} fill="#94a3b8">
                      {t}
                    </text>
                  </g>
                );
              })}
            </svg>

            <div className="mt-3 grid grid-cols-3 gap-2 text-center">
              {["softmax(QKᵀ/√d)", "Concat по d_head", "W^O → выход"].map((f) => (
                <div
                  key={f}
                  className="rounded-lg border border-white/10 bg-slate-900/60 px-2 py-1.5 font-mono text-[10px] text-slate-400"
                >
                  {f}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
