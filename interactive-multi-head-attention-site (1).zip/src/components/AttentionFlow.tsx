import { headColor, truncate, type Mat } from "../lib/attention";

/** SVG-диаграмма потоков внимания: снизу запросы, сверху ключи. */
export function AttentionFlow({
  weights,
  tokens,
  headId,
  showLabels = true,
  height = 300,
}: {
  weights: Mat;
  tokens: string[];
  headId: number;
  showLabels?: boolean;
  height?: number;
}) {
  const n = tokens.length;
  if (!n) return null;
  const W = 1000;
  const H = height;
  const topY = 46;
  const botY = H - 52;
  const margin = 70;
  const step = n > 1 ? (W - margin * 2) / (n - 1) : 0;
  const x = (i: number) => (n > 1 ? margin + i * step : W / 2);
  const color = headColor(headId);

  const links: { i: number; j: number; w: number }[] = [];
  for (let i = 0; i < n; i++) {
    for (let j = 0; j < n; j++) {
      const w = weights[i][j];
      if (isFinite(w) && w > 0.004) links.push({ i, j, w });
    }
  }

  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="w-full" style={{ height }}>
      <defs>
        <radialGradient id={`glow-${headId}`} cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor={color} stopOpacity="0.35" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </radialGradient>
      </defs>

      {links.map(({ i, j, w }) => {
        const x1 = x(i);
        const y1 = botY - 20;
        const x2 = x(j);
        const y2 = topY + 20;
        const cx = (x1 + x2) / 2;
        const cy = (y1 + y2) / 2 - 40 + Math.abs(x2 - x1) * 0.08;
        return (
          <path
            key={`${i}-${j}`}
            d={`M ${x1} ${y1} Q ${cx} ${cy} ${x2} ${y2}`}
            fill="none"
            stroke={color}
            strokeWidth={1 + w * 14}
            strokeOpacity={0.08 + w * 0.55}
            strokeLinecap="round"
          />
        );
      })}

      {tokens.map((_, i) => (
        <g key={`k${i}`}>
          <circle cx={x(i)} cy={topY} r={18} fill={`url(#glow-${headId})`} />
          <circle
            cx={x(i)}
            cy={topY}
            r={16}
            fill="#0b1220"
            stroke={color}
            strokeWidth={2}
            opacity={0.95}
          />
          <text
            x={x(i)}
            y={topY + 4}
            textAnchor="middle"
            fontSize={11}
            fill={color}
            fontFamily="JetBrains Mono, monospace"
          >
            {i + 1}
          </text>
        </g>
      ))}

      {tokens.map((_, i) => (
        <g key={`q${i}`}>
          <circle
            cx={x(i)}
            cy={botY}
            r={16}
            fill="#0b1220"
            stroke={color}
            strokeWidth={2}
            opacity={0.95}
          />
          <text
            x={x(i)}
            y={botY + 4}
            textAnchor="middle"
            fontSize={11}
            fill={color}
            fontFamily="JetBrains Mono, monospace"
          >
            {i + 1}
          </text>
        </g>
      ))}

      {showLabels && (
        <>
          <text x={16} y={topY + 4} fontSize={13} fill="#64748b" fontWeight={600}>
            K (ключи)
          </text>
          <text x={16} y={botY + 4} fontSize={13} fill="#64748b" fontWeight={600}>
            Q (запросы)
          </text>
          {tokens.map((t, i) => (
            <text
              key={`kl${i}`}
              x={x(i)}
              y={topY - 28}
              textAnchor="middle"
              fontSize={12}
              fill="#94a3b8"
            >
              {truncate(t, 12)}
            </text>
          ))}
          {tokens.map((t, i) => (
            <text
              key={`ql${i}`}
              x={x(i)}
              y={botY + 32}
              textAnchor="middle"
              fontSize={12}
              fill="#94a3b8"
            >
              {truncate(t, 12)}
            </text>
          ))}
        </>
      )}
    </svg>
  );
}
