import { useState } from "react";
import { Card, SectionTitle } from "./ui";
import { cn } from "../utils/cn";

interface Question {
  q: string;
  options: string[];
  correct: number;
  explain: string;
}

const QUESTIONS: Question[] = [
  {
    q: "Какова размерность выхода одной головы внимания?",
    options: ["d_model", "d_model / h", "d_model · h", "1"],
    correct: 1,
    explain:
      "В multi-head attention принято делить d_model на h равных частей: d_head = d_model / h. Конкатенация h голов снова даёт вектор длины d_model.",
  },
  {
    q: "Зачем скалярные произведения Q·K делят на √d_k?",
    options: [
      "Чтобы уменьшить число параметров",
      "Чтобы softmax не вырождался в «всё или ничего»",
      "Чтобы нормализовать входные данные",
      "Чтобы ускорить матричное умножение",
    ],
    correct: 1,
    explain:
      "При больших d_k логиты Q·K становятся большими по модулю, softmax распределяет почти всю вероятность на один токен, и градиенты исчезают. Деление на √d_k возвращает масштаб.",
  },
  {
    q: "Что делает матрица W^O?",
    options: [
      "Проецирует вход в Q, K и V",
      "Смешивает информацию разных голов после конкатенации",
      "Нормализует выход softmax",
      "Убирает маску из матрицы внимания",
    ],
    correct: 1,
    explain:
      "Каждая голова использует свои W_Q, W_K, W_V, а W^O — общая для всех: она позволяет смешивать признаки, собранные разными головами, в один итоговый вектор.",
  },
  {
    q: "Какую маску используют генеративные decoder-модели (GPT)?",
    options: [
      "Padding mask",
      "Причинную (causal): токен видит только прошлое",
      "Никакую",
      "Случайную",
    ],
    correct: 1,
    explain:
      "Причинная маска запрещает смотреть на будущие позиции (j > i), поэтому модель можно обучать параллельно, а генерировать последовательно.",
  },
  {
    q: "Чему равна сумма весов внимания в одной строке матрицы A = softmax(QKᵀ)?",
    options: ["0", "d_k", "1", "√d_k"],
    correct: 2,
    explain:
      "Softmax нормирует каждую строку: все веса неотрицательны и в сумме равны 1. Это «распределение внимания» одного токена по ключам.",
  },
  {
    q: "Что произойдёт, если у всех голов сделать абсолютно одинаковые веса?",
    options: [
      "Модель станет точнее, потому что не тратит ёмкость",
      "Головы станут дубликатами, и multi-head не даст пользы",
      "Обучение упадёт из-за переполнения",
      "Модель сможет видеть только 1 токен",
    ],
    correct: 1,
    explain:
      "Если матрицы W_Q, W_K, W_V у голов совпадают, все головы дают одинаковую матрицу внимания. Конкатенация ничего не добавляет — это ровно одна голова, повторённая h раз.",
  },
  {
    q: "Как называется операция, склеивающая выходы всех голов?",
    options: ["Residual connection", "Concatenation", "Softmax", "Layer normalization"],
    correct: 1,
    explain:
      "Concat склеивает h векторов длины d_head в один вектор длины d_model, после чего применяется общая проекция W^O.",
  },
];

export function Quiz() {
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [showAll, setShowAll] = useState(false);

  const answered = Object.keys(answers).length;
  const correct = QUESTIONS.reduce(
    (acc, q, i) => acc + (answers[i] === q.correct ? 1 : 0),
    0
  );
  const finished = answered === QUESTIONS.length;

  return (
    <section id="quiz" className="relative mx-auto max-w-4xl px-4 py-20 sm:px-6 sm:py-24">
      <SectionTitle
        eyebrow="Проверьте себя"
        title="Квиз по multi-head attention"
        subtitle="Семь вопросов на механику, формулы и подводные камни. Ответы можно менять — итоговый счёт пересчитается."
        icon={
          <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth={2.2}>
            <path d="M9 9a3 3 0 1 1 4.5 2.6c-.8.5-1.5 1.2-1.5 2.4M12 17.5h.01" />
            <circle cx="12" cy="12" r="9" />
          </svg>
        }
      />

      <Card className="mb-6 p-5">
        <div className="mb-2 flex items-center justify-between text-sm">
          <span className="text-slate-400">
            Отвечено: <span className="font-mono text-slate-200">{answered}</span> / {QUESTIONS.length}
          </span>
          <span className="font-mono text-slate-300">
            Верно: <span className="text-emerald-400">{correct}</span>
          </span>
        </div>
        <div className="h-2 overflow-hidden rounded-full bg-slate-800">
          <div
            className="h-full rounded-full bg-gradient-to-r from-sky-400 to-emerald-400 transition-all"
            style={{ width: `${(answered / QUESTIONS.length) * 100}%` }}
          />
        </div>
        <div className="mt-3 flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setShowAll((s) => !s)}
            className="rounded-lg border border-white/10 bg-white/5 px-3 py-1.5 text-xs font-medium text-slate-300 transition hover:bg-white/10"
          >
            {showAll ? "Скрыть ответы" : "Показать все ответы"}
          </button>
          <button
            type="button"
            onClick={() => {
              setAnswers({});
              setShowAll(false);
            }}
            className="rounded-lg border border-white/10 bg-white/5 px-3 py-1.5 text-xs font-medium text-slate-300 transition hover:bg-white/10"
          >
            Начать заново
          </button>
          {finished && (
            <span className="rounded-lg bg-emerald-400/10 px-3 py-1.5 text-xs font-semibold text-emerald-300">
              {correct === QUESTIONS.length
                ? "Идеально! 🎉"
                : correct >= QUESTIONS.length - 2
                ? "Отличный результат 👏"
                : "Стоит перечитать разбор 🙂"}
            </span>
          )}
        </div>
      </Card>

      <div className="space-y-4">
        {QUESTIONS.map((q, qi) => {
          const picked = answers[qi];
          const done = picked !== undefined;
          return (
            <Card key={qi} className="p-5">
              <div className="mb-3 flex items-start gap-3">
                <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-lg bg-white/5 font-mono text-xs font-bold text-slate-300">
                  {qi + 1}
                </span>
                <h3 className="text-sm font-semibold text-white sm:text-base">{q.q}</h3>
              </div>
              <div className="grid gap-2">
                {q.options.map((opt, oi) => {
                  const isCorrect = oi === q.correct;
                  const isPicked = picked === oi;
                  const reveal = done || showAll;
                  return (
                    <button
                      key={oi}
                      type="button"
                      onClick={() => setAnswers((a) => ({ ...a, [qi]: oi }))}
                      className={cn(
                        "flex items-start gap-3 rounded-xl border px-3 py-2.5 text-left text-sm transition",
                        reveal && isCorrect
                          ? "border-emerald-400/50 bg-emerald-400/10 text-emerald-200"
                          : reveal && isPicked
                          ? "border-rose-400/50 bg-rose-400/10 text-rose-200"
                          : "border-white/10 bg-slate-900/40 text-slate-300 hover:border-white/25 hover:bg-white/5",
                        done && !isPicked && !isCorrect && "opacity-60"
                      )}
                    >
                      <span
                        className={cn(
                          "mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded-full border text-[9px]",
                          reveal && isCorrect
                            ? "border-emerald-400 bg-emerald-400 text-slate-950"
                            : reveal && isPicked
                            ? "border-rose-400 bg-rose-400 text-slate-950"
                            : "border-white/25"
                        )}
                      >
                        {reveal && isCorrect ? "✓" : reveal && isPicked ? "✕" : ""}
                      </span>
                      <span>{opt}</span>
                    </button>
                  );
                })}
              </div>
              {(done || showAll) && (
                <div className="mt-3 rounded-xl border border-sky-400/20 bg-sky-400/[0.06] p-3 text-xs leading-relaxed text-slate-300">
                  <span className="font-semibold text-sky-300">Почему: </span>
                  {q.explain}
                </div>
              )}
            </Card>
          );
        })}
      </div>
    </section>
  );
}
