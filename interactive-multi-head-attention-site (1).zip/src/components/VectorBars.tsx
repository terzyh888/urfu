import { fmt } from "../lib/attention";

/** Горизонтальные бары для вектора (Q, K, V, выход и т.п.) */
export function VectorBars({
  values,
  color = "#38bdf8",
  label,
  max,
  digits = 2,
  bars = 24,
}: {
  values: number[];
  color?: string;
  label?: string;
  max?: number;
  digits?: number;
  bars?: number;
}) {
  if (!values.length) return null;
  const absMax = max ?? Math.max(...values.map((v) => Math.abs(v)), 1e-9);
  return (
    <div>
      {label && (
        <div className="mb-2 flex items-baseline justify-between">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
            {label}
          </span>
          <span className="font-mono text-[10px] text-slate-500">n = {values.length}</span>
        </div>
      )}
      <div className="space-y-[3px]">
        {values.slice(0, bars).map((v, i) => {
          const w = (Math.abs(v) / absMax) * 50;
          const positive = v >= 0;
          return (
            <div key={i} className="flex items-center gap-2">
              <span className="w-6 shrink-0 text-right font-mono text-[9px] text-slate-600">
                {i}
              </span>
              <div className="relative h-3.5 flex-1 rounded bg-slate-900/60">
                <div className="absolute inset-y-0 left-1/2 w-px bg-white/10" />
                <div
                  className="absolute inset-y-0 rounded-sm"
                  style={{
                    left: positive ? "50%" : `${50 - w}%`,
                    width: `${w}%`,
                    background: positive ? color : "#f472b6",
                    opacity: 0.85,
                  }}
                />
              </div>
              <span className="w-12 shrink-0 font-mono text-[9px] text-slate-400">
                {fmt(v, digits)}
              </span>
            </div>
          );
        })}
        {values.length > bars && (
          <div className="pt-1 text-center text-[10px] text-slate-600">
            …ещё {values.length - bars} измерений
          </div>
        )}
      </div>
    </div>
  );
}
