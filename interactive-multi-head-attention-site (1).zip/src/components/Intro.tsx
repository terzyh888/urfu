import { Card, SectionTitle } from "./ui";

function Formula({ children, note }: { children: React.ReactNode; note?: string }) {
  return (
    <div className="rounded-2xl border border-sky-400/20 bg-sky-400/[0.06] p-5">
      <div className="overflow-x-auto font-mono text-sm text-sky-200 sm:text-base">{children}</div>
      {note && <div className="mt-3 text-xs leading-relaxed text-slate-400">{note}</div>}
    </div>
  );
}

const ROLES = [
  {
    key: "Q",
    title: "Query — запрос",
    color: "#38bdf8",
    text: "Что я ищу в окружении? Формируется из текущего токена: «на что мне нужно посмотреть».",
    example: "Запрос: «кто здесь главный?»",
  },
  {
    key: "K",
    title: "Key — ключ",
    color: "#fbbf24",
    text: "На что меня могут узнать? Каждый токен предъявляет «визитку» — чем он может быть полезен.",
    example: "Визитка: «я — объект внимания»",
  },
  {
    key: "V",
    title: "Value — значение",
    color: "#4ade80",
    text: "Что именно я передам дальше, если на меня посмотрят? Это и есть полезная информация.",
    example: "Содержимое: «я — окно»",
  },
];

const BENEFITS = [
  {
    title: "Разные подпространства",
    text: "Каждая голова живёт в своём подпространстве размерности d_head. Одна ищет синтаксис, другая — смысловые связи, третья — позиционные зависимости.",
    icon: "M4 7h16M4 12h10M4 17h6",
  },
  {
    title: "Параллельные зависимости",
    text: "Голова «кто прилагательное» и голова «какой объект» смотрят на один и тот же текст одновременно, а не по очереди.",
    icon: "M4 6h6v6H4zM14 12h6v6h-6z",
  },
  {
    title: "Больше выразительности",
    text: "Конкатенация голов даёт модели d_model измерений, каждое из которых описывает контекст по-своему — как ансамбль экспертов.",
    icon: "M12 3l2.2 5.5L20 9l-4 4 1 6-5-3-5 3 1-6-4-4 5.8-.5z",
  },
];

export function Intro() {
  return (
    <section id="intro" className="relative mx-auto max-w-7xl px-4 py-20 sm:px-6 sm:py-28">
      <SectionTitle
        eyebrow="Основы"
        title="Что такое внимание и зачем их несколько"
        subtitle="Attention — это способ для каждого токена взвешенно собрать информацию из всех остальных токенов контекста. Multi-Head Attention запускает несколько таких «взглядов» параллельно."
        icon={
          <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth={2.2}>
            <circle cx="12" cy="12" r="9" />
            <path d="M12 7v5l3 2" />
          </svg>
        }
      />

      <div className="grid gap-6 lg:grid-cols-[1.1fr_1fr]">
        <div className="space-y-6">
          <div className="grid gap-4 sm:grid-cols-3">
            {ROLES.map((r) => (
              <Card key={r.key} className="p-5">
                <div className="mb-2 flex items-center gap-2">
                  <span
                    className="flex h-7 w-7 items-center justify-center rounded-lg font-mono text-sm font-bold"
                    style={{ background: `${r.color}22`, color: r.color }}
                  >
                    {r.key}
                  </span>
                  <span className="text-sm font-semibold text-white">{r.title}</span>
                </div>
                <p className="text-sm leading-relaxed text-slate-400">{r.text}</p>
                <p className="mt-3 rounded-lg bg-slate-900/60 px-3 py-2 font-mono text-[11px] text-slate-400">
                  {r.example}
                </p>
              </Card>
            ))}
          </div>

          <div className="space-y-3">
            <Formula note="Каждая строка softmax даёт распределение вероятностей по ключам: сумма весов всегда равна 1.">
              Attention(Q, K, V) = softmax( QK<sup>T</sup> / √d<sub>k</sub> ) · V
            </Formula>
            <Formula note="Головы считаются параллельно, их выходы склеиваются и пропускаются через общую матрицу W^O — это и есть multi-head attention.">
              MultiHead(Q, K, V) = Concat(head<sub>1</sub>, …, head<sub>h</sub>) · W<sup>O</sup>
            </Formula>
          </div>
        </div>

        <div className="space-y-4">
          <Card className="p-6" glow="#38bdf8">
            <h3 className="text-lg font-bold text-white">Аналогия: команда экспертов</h3>
            <p className="mt-3 text-sm leading-relaxed text-slate-400">
              Представьте, что вы читаете текст в комнате. Одна голова внимания — это один человек,
              который ищет только <span className="text-sky-300">смысловую связь</span>. Другая следит за{" "}
              <span className="text-amber-300">согласованием</span>. Третья замечает{" "}
              <span className="text-emerald-300">отрицания</span>. Каждый смотрит на весь текст, но «очками» своими.
            </p>
            <p className="mt-3 text-sm leading-relaxed text-slate-400">
              Одна голова с d_head = d_model — это как надеть одни очки на все задачи: они либо
              подходят для одной роли, но теряются в остальных. Несколько голов делят d_model на
              части и специализируются.
            </p>
          </Card>

          <div className="grid gap-4">
            {BENEFITS.map((b) => (
              <Card key={b.title} className="flex gap-4 p-5">
                <span className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-sky-400/10 text-sky-300">
                  <svg viewBox="0 0 24 24" className="h-4.5 w-4.5" fill="none" stroke="currentColor" strokeWidth={2}>
                    <path d={b.icon} />
                  </svg>
                </span>
                <div>
                  <h4 className="text-sm font-semibold text-white">{b.title}</h4>
                  <p className="mt-1 text-sm leading-relaxed text-slate-400">{b.text}</p>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
