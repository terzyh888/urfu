import { useCallback, useMemo, useState } from "react";
import { computeAttn, type AttnConfig, type HeadConfig } from "./attention";

export interface TokenPreset {
  label: string;
  hint: string;
  tokens: string[];
}

export const TOKEN_PRESETS: TokenPreset[] = [
  {
    label: "Русская фраза",
    hint: "«Кот сидит на окне и смотрит вниз»",
    tokens: ["Кот", "сидит", "на", "окне", "и", "смотрит", "вниз"],
  },
  {
    label: "Английский текст",
    hint: "классический пример из статьи «Attention Is All You Need»",
    tokens: ["The", "animal", "didn’t", "cross", "the", "street", "because", "it", "was", "tired"],
  },
  {
    label: "Вопрос → ответ",
    hint: "показывает, как голова «ищет» ответ",
    tokens: ["Что", "такое", "attention", "?", "→", "механизм", "выбора", "контекста"],
  },
  {
    label: "Код",
    hint: "синтаксические связи между токенами",
    tokens: ["def", "attend", "(", "q", ",", "k", ",", "v", ")", "→", "return", "softmax"],
  },
  {
    label: "Отрицание",
    hint: "где нужно «прицелиться» в слово «not»",
    tokens: ["He", "didn’t", "like", "that", "movie", "because", "it", "was", "bad"],
  },
];

export function defaultHeads(n: number): HeadConfig[] {
  return Array.from({ length: n }, (_, i) => ({
    id: i,
    target: i % 5,
    bias: 0,
    temp: 1,
  }));
}

export function useLab() {
  const [tokens, setTokensState] = useState<string[]>(TOKEN_PRESETS[0].tokens);
  const [dModel, setDModelState] = useState(32);
  const [nHeads, setNHeadsState] = useState(4);
  const [scaled, setScaled] = useState(true);
  const [causal, setCausal] = useState(false);
  const [seed, setSeed] = useState(7);
  const [heads, setHeads] = useState<HeadConfig[]>(defaultHeads(4));
  const [selectedHead, setSelectedHead] = useState(0);
  const [selectedToken, setSelectedToken] = useState(0);
  const [autoRandomize, setAutoRandomize] = useState(false);

  const clampToken = useCallback(
    (t: string[]) => {
      const clean = t.map((x) => x.trim()).filter((x) => x.length > 0);
      return clean.length ? clean.slice(0, 12) : ["токен"];
    },
    []
  );

  const setTokens = useCallback(
    (t: string[]) => {
      const next = clampToken(t);
      setTokensState(next);
      setHeads((prev) => prev.map((h) => ({ ...h, target: Math.min(h.target, next.length - 1) })));
      setSelectedToken((s) => Math.min(s, next.length - 1));
    },
    [clampToken]
  );

  const setNHeads = useCallback((n: number) => {
    setNHeadsState(n);
    setHeads((prev) => {
      const next = defaultHeads(n);
      return next.map((h, i) => ({ ...h, target: prev[i]?.target ?? h.target, bias: prev[i]?.bias ?? 0, temp: prev[i]?.temp ?? 1 }));
    });
    setSelectedHead((s) => Math.min(s, n - 1));
  }, []);

  const setDModel = useCallback((d: number) => {
    setDModelState(d);
  }, []);

  const updateHead = useCallback((id: number, patch: Partial<HeadConfig>) => {
    setHeads((prev) => prev.map((h) => (h.id === id ? { ...h, ...patch } : h)));
  }, []);

  const resetHeads = useCallback(() => {
    setHeads(defaultHeads(nHeads));
  }, [nHeads]);

  const randomize = useCallback(() => {
    setSeed((s) => s + 1);
  }, []);

  const config: AttnConfig = useMemo(
    () => ({ tokens, dModel, nHeads, scaled, causal, seed, heads }),
    [tokens, dModel, nHeads, scaled, causal, seed, heads]
  );

  const result = useMemo(() => computeAttn(config), [config]);

  /* контрольный запуск: те же веса-эмбеддинги, но ровно одна голова */
  const single = useMemo(
    () =>
      computeAttn({
        ...config,
        nHeads: 1,
        heads: [{ id: 0, target: 0, bias: 0, temp: 1 }],
      }),
    [config]
  );

  /* косинусная близость выходов multi-head и single-head по каждому токену */
  const outputSimilarity = useMemo(() => {
    if (!result.n) return [];
    const out: number[] = [];
    for (let i = 0; i < result.n; i++) {
      out.push(cos(result.output[i], single.output[i]));
    }
    return out;
  }, [result, single]);

  return {
    tokens,
    setTokens,
    dModel,
    setDModel,
    nHeads,
    setNHeads,
    scaled,
    setScaled,
    causal,
    setCausal,
    seed,
    setSeed,
    randomize,
    heads,
    updateHead,
    resetHeads,
    selectedHead,
    setSelectedHead,
    selectedToken,
    setSelectedToken,
    autoRandomize,
    setAutoRandomize,
    config,
    result,
    single,
    outputSimilarity,
  };
}

function cos(a: number[], b: number[]): number {
  let d = 0;
  let na = 0;
  let nb = 0;
  for (let i = 0; i < a.length; i++) {
    d += a[i] * b[i];
    na += a[i] * a[i];
    nb += b[i] * b[i];
  }
  if (na === 0 || nb === 0) return 0;
  return d / (Math.sqrt(na) * Math.sqrt(nb));
}

export type Lab = ReturnType<typeof useLab>;
