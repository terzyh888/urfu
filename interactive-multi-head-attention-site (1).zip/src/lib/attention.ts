/* =========================================================================
   Ядро вычислений Multi-Head Attention
   Все операции — чистый TypeScript, без внешних библиотек.
   ========================================================================= */

export type Vec = number[];
export type Mat = number[][]; // матрица: rows x cols

/* ============================ Генератор случайных чисел ================== */

export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function hashString(str: string): number {
  let h = 2166136261 >>> 0;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

export function gauss(rng: () => number): number {
  let u = 0;
  let v = 0;
  while (u === 0) u = rng();
  while (v === 0) v = rng();
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
}

/* ============================== Линейная алгебра ======================== */

export function matMul(a: Mat, b: Mat): Mat {
  const n = a.length;
  if (n === 0) return [];
  const k = b.length;
  const m = b[0].length;
  const out: Mat = Array.from({ length: n }, () => new Array(m).fill(0));
  for (let i = 0; i < n; i++) {
    const arow = a[i];
    const orow = out[i];
    for (let p = 0; p < k; p++) {
      const aip = arow[p];
      if (aip === 0) continue;
      const brow = b[p];
      for (let j = 0; j < m; j++) orow[j] += aip * brow[j];
    }
  }
  return out;
}

export function dot(a: Vec, b: Vec): number {
  let s = 0;
  const n = Math.min(a.length, b.length);
  for (let i = 0; i < n; i++) s += a[i] * b[i];
  return s;
}

export function transpose(m: Mat): Mat {
  if (m.length === 0) return [];
  const cols = m[0].length;
  const out: Mat = Array.from({ length: cols }, () => new Array(m.length).fill(0));
  for (let i = 0; i < m.length; i++) {
    for (let j = 0; j < cols; j++) out[j][i] = m[i][j];
  }
  return out;
}

export function softmax(xs: Vec): Vec {
  if (xs.length === 0) return [];
  let max = -Infinity;
  for (const x of xs) if (x > max) max = x;
  if (!isFinite(max)) return xs.map(() => 1 / xs.length);
  let sum = 0;
  const exps = xs.map((x) => {
    const e = Math.exp(x - max);
    sum += e;
    return e;
  });
  return exps.map((e) => e / sum);
}

export function cosine(a: Vec, b: Vec): number {
  let dotab = 0;
  let na = 0;
  let nb = 0;
  const n = Math.min(a.length, b.length);
  for (let i = 0; i < n; i++) {
    dotab += a[i] * b[i];
    na += a[i] * a[i];
    nb += b[i] * b[i];
  }
  if (na === 0 || nb === 0) return 0;
  return dotab / (Math.sqrt(na) * Math.sqrt(nb));
}

export function entropyOf(p: Vec): number {
  let h = 0;
  for (const x of p) if (x > 0) h -= x * Math.log(x);
  return h; // натуральный логарифм; максимум = ln(n)
}

export function mean(xs: number[]): number {
  if (xs.length === 0) return 0;
  return xs.reduce((a, b) => a + b, 0) / xs.length;
}

export function fmt(x: number, digits = 2): string {
  if (!isFinite(x)) return x > 0 ? "∞" : "-∞";
  if (Math.abs(x) >= 1000 || (Math.abs(x) < 0.001 && x !== 0)) return x.toExponential(1);
  return x.toFixed(digits);
}

/* ============================== Конфигурация ============================ */

export interface HeadConfig {
  id: number;
  /** индекс токена-ключа, на который добавляется смещение логитов */
  target: number;
  /** добавочное смещение (в логитах) к целевому ключу */
  bias: number;
  /** температура: >1 — резче распределение, <1 — площе */
  temp: number;
}

export interface AttnConfig {
  tokens: string[];
  dModel: number;
  nHeads: number;
  scaled: boolean;
  causal: boolean;
  seed: number;
  heads: HeadConfig[];
}

export interface HeadResult {
  id: number;
  dHead: number;
  Q: Mat;
  K: Mat;
  V: Mat;
  /** логиты после масштабирования, температуры и смещения (маска = -∞) */
  logits: Mat;
  /** вероятности после softmax (строки суммируются в 1) */
  weights: Mat;
  /** результат головы: n x dHead */
  out: Mat;
  entropy: number[];
  topKey: number[];
}

export interface AttnResult {
  config: AttnConfig;
  n: number;
  dHead: number;
  heads: HeadResult[];
  /** конкатенация голов: n x dModel */
  concat: Mat;
  /** финальный выход после W^O: n x dModel */
  output: Mat;
  /** попарная косинусная схожесть матриц внимания голов */
  similarity: number[][];
  /** средняя схожесть между разными головами (0..1) */
  redundancy: number;
  /** оценка числа действительно различных голов */
  effectiveHeads: number;
}

/* ========================== Эмбеддинги токенов ========================== */

export function buildEmbeddings(tokens: string[], dModel: number, seed: number): Mat {
  return tokens.map((tok, i) => {
    const rng = mulberry32((hashString(tok) ^ Math.imul(seed + 1, 2654435761)) >>> 0);
    const emb: Vec = Array.from({ length: dModel }, () => gauss(rng) * 0.9);
    const prng = mulberry32((Math.imul(seed + 17, 2246822519) ^ Math.imul(i + 1, 3266489917)) >>> 0);
    for (let j = 0; j < dModel; j++) emb[j] += gauss(prng) * 0.35; // позиционная часть
    return emb;
  });
}

function randMatrix(rng: () => number, rows: number, cols: number, std: number): Mat {
  return Array.from({ length: rows }, () => Array.from({ length: cols }, () => gauss(rng) * std));
}

/* ============================ Основное вычисление ======================== */

export function computeAttn(cfg: AttnConfig): AttnResult {
  const n = cfg.tokens.length;
  const dModel = cfg.dModel;
  const dHead = Math.max(1, Math.round(dModel / cfg.nHeads));
  const X = buildEmbeddings(cfg.tokens, dModel, cfg.seed);
  const heads: HeadResult[] = [];

  for (let h = 0; h < cfg.nHeads; h++) {
    const hc: HeadConfig = cfg.heads[h] ?? { id: h, target: 0, bias: 0, temp: 1 };
    const rng = mulberry32((Math.imul(cfg.seed + 101, 2246822519) ^ Math.imul(h + 1, 3266489917)) >>> 0);
    const std = Math.sqrt(2 / (dModel + dHead));
    const Wq = randMatrix(rng, dModel, dHead, std);
    const Wk = randMatrix(rng, dModel, dHead, std);
    const Wv = randMatrix(rng, dModel, dHead, std);

    const Q = matMul(X, Wq);
    const K = matMul(X, Wk);
    const V = matMul(X, Wv);

    const denom = cfg.scaled ? Math.sqrt(dHead) : 1;
    const logits: Mat = [];
    const weights: Mat = [];
    const entropy: number[] = [];
    const topKey: number[] = [];

    for (let i = 0; i < n; i++) {
      const row: number[] = [];
      for (let j = 0; j < n; j++) {
        if (cfg.causal && j > i) {
          row.push(-Infinity);
          continue;
        }
        const base = dot(Q[i], K[j]) / denom;
        // стандартная температура: логиты делятся на T (T>1 — площе, T<1 — резче)
        const scaledT = base / hc.temp;
        const biased = j === hc.target ? scaledT + hc.bias : scaledT;
        row.push(biased);
      }
      logits.push(row);
      const p = softmax(row);
      weights.push(p);
      entropy.push(entropyOf(p));
      let best = 0;
      for (let j = 1; j < n; j++) if (p[j] > p[best]) best = j;
      topKey.push(best);
    }

    const out = matMul(weights, V);
    heads.push({ id: h, dHead, Q, K, V, logits, weights, out, entropy, topKey });
  }

  /* конкатенация голов по последнему измерению */
  const concat: Mat = [];
  for (let i = 0; i < n; i++) {
    const row: number[] = [];
    for (const head of heads) row.push(...head.out[i]);
    concat.push(row);
  }

  /* выходное проекция W^O */
  const orng = mulberry32((Math.imul(cfg.seed + 777, 2654435761) ^ 0x5f3759df) >>> 0);
  const Wo = randMatrix(orng, dModel, dModel, 1 / Math.sqrt(dModel));
  const output = matMul(concat, Wo);

  /* попарная схожесть голов */
  const similarity: number[][] = [];
  for (let i = 0; i < heads.length; i++) {
    const row: number[] = [];
    for (let j = 0; j < heads.length; j++) {
      row.push(cosine(heads[i].weights.flat(), heads[j].weights.flat()));
    }
    similarity.push(row);
  }
  let offSum = 0;
  let offCount = 0;
  for (let i = 0; i < heads.length; i++) {
    for (let j = 0; j < heads.length; j++) {
      if (i !== j) {
        offSum += similarity[i][j];
        offCount++;
      }
    }
  }
  const redundancy = offCount ? offSum / offCount : 0;
  const effectiveHeads = Math.max(1, heads.length * (1 - redundancy));

  return {
    config: cfg,
    n,
    dHead,
    heads,
    concat,
    output,
    similarity,
    redundancy,
    effectiveHeads,
  };
}

/* ============================== Утилиты ================================ */

export const HEAD_COLORS = [
  "#38bdf8", // sky
  "#f472b6", // pink
  "#fbbf24", // amber
  "#4ade80", // green
  "#a78bfa", // violet
  "#fb7185", // rose
  "#22d3ee", // cyan
  "#f59e0b", // orange
];

export function headColor(i: number): string {
  return HEAD_COLORS[i % HEAD_COLORS.length];
}

/** Цветовая шкала для матриц внимания (тёмно-синий → оранжевый) */
export function heatColor(v: number): string {
  const t = Math.max(0, Math.min(1, v));
  const h = 205 - 185 * t;
  const s = 85 - 18 * t;
  const l = 17 + 53 * t;
  return `hsl(${h.toFixed(0)} ${s.toFixed(0)}% ${l.toFixed(0)}%)`;
}

export function heatTextColor(v: number): string {
  const t = Math.max(0, Math.min(1, v));
  return 17 + 53 * t > 52 ? "#0b1220" : "#e2e8f0";
}

export function truncate(s: string, n = 10): string {
  return s.length > n ? s.slice(0, n - 1) + "…" : s;
}
