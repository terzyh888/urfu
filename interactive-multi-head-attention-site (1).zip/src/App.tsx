import { Nav } from "./components/Nav";
import { Hero } from "./components/Hero";
import { Intro } from "./components/Intro";
import { Playground } from "./components/Playground";
import { StepByStep } from "./components/StepByStep";
import { Comparison } from "./components/Comparison";
import { MaskingLab } from "./components/MaskingLab";
import { CodeSection } from "./components/CodeSection";
import { Quiz } from "./components/Quiz";
import { useLab } from "./lib/lab";
import { Card, Reveal } from "./components/ui";

const HOW_TO = [
  {
    n: "01",
    t: "Загрузите текст",
    d: "Возьмите готовый пример («Кот сидит на окне…») или впишите свой — по одному токену в строке.",
  },
  {
    n: "02",
    t: "Настройте головы",
    d: "Выберите число голов, размерность модели, а для каждой головы — свой целевой токен, смещение и температуру.",
  },
  {
    n: "03",
    t: "Смотрите на результат",
    d: "Матрицы внимания, потоки, векторы Q/K/V и итоговый выход пересчитываются мгновенно.",
  },
];

export default function App() {
  const lab = useLab();

  return (
    <div className="relative min-h-screen overflow-x-hidden bg-slate-950 text-slate-200">
      <Nav />
      <main>
        <Hero />

        <section className="mx-auto max-w-7xl px-4 pb-4 sm:px-6">
          <div className="grid gap-4 md:grid-cols-3">
            {HOW_TO.map((h) => (
              <Card key={h.n} className="p-5">
                <div className="font-mono text-xs font-bold text-sky-400">{h.n}</div>
                <h3 className="mt-2 text-sm font-semibold text-white">{h.t}</h3>
                <p className="mt-1.5 text-sm leading-relaxed text-slate-400">{h.d}</p>
              </Card>
            ))}
          </div>
        </section>

        <Reveal>
          <Intro />
        </Reveal>
        <Reveal>
          <Playground lab={lab} />
        </Reveal>
        <Reveal>
          <StepByStep lab={lab} />
        </Reveal>
        <Reveal>
          <Comparison lab={lab} />
        </Reveal>
        <Reveal>
          <MaskingLab lab={lab} />
        </Reveal>
        <Reveal>
          <CodeSection />
        </Reveal>
        <Reveal>
          <Quiz />
        </Reveal>
      </main>

      <footer className="border-t border-white/10 bg-slate-950/80">
        <div className="mx-auto grid max-w-7xl gap-8 px-4 py-12 sm:px-6 md:grid-cols-[1.4fr_1fr_1fr]">
          <div>
            <div className="flex items-center gap-2.5">
              <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-sky-400 to-violet-500">
                <svg viewBox="0 0 24 24" className="h-4.5 w-4.5 text-slate-950" fill="none" stroke="currentColor" strokeWidth={2.4}>
                  <circle cx="6" cy="6" r="2" />
                  <circle cx="6" cy="18" r="2" />
                  <circle cx="18" cy="12" r="2" />
                  <path d="M7.6 7.4 16.4 11M7.6 16.6 16.4 13" />
                </svg>
              </span>
              <span className="font-bold text-white">MHA.Lab</span>
            </div>
            <p className="mt-3 max-w-sm text-sm leading-relaxed text-slate-500">
              Интерактивный учебник по механизму многоголового внимания. Все вычисления
              выполняются в браузере на чистом TypeScript — без библиотек и без сервера.
            </p>
          </div>
          <div>
            <h4 className="mb-3 text-xs font-semibold uppercase tracking-wider text-slate-400">
              Разделы
            </h4>
            <ul className="space-y-2 text-sm">
              {[
                ["#intro", "Основы внимания"],
                ["#playground", "Песочница"],
                ["#steps", "Разбор по шагам"],
                ["#compare", "Одна голова vs много"],
                ["#masking", "Маски"],
                ["#code", "Код"],
                ["#quiz", "Квиз"],
              ].map(([href, label]) => (
                <li key={href}>
                  <a href={href} className="text-slate-400 transition hover:text-sky-300">
                    {label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h4 className="mb-3 text-xs font-semibold uppercase tracking-wider text-slate-400">
              Формулы сайта
            </h4>
            <ul className="space-y-2 font-mono text-[11px] text-slate-500">
              <li>Attention(Q,K,V) = softmax(QKᵀ/√d_k)·V</li>
              <li>MultiHead = Concat(h₁…hₕ)·W^O</li>
              <li>d_head = d_model / h</li>
              <li>mask = triu(−∞, diagonal=1)</li>
            </ul>
          </div>
        </div>
        <div className="border-t border-white/5 px-4 py-5 text-center text-xs text-slate-600">
          Основано на статье «Attention Is All You Need» (Vaswani et al., 2017) — архитектуре
          Transformer, с которой началась эпоха больших языковых моделей.
        </div>
      </footer>
    </div>
  );
}
